import { Component } from '@angular/core';
import {ActionSheetController, NavController} from 'ionic-angular';
import {ServiceSingleton} from "../../providers/service-singleton";
import { Camera, CameraOptions } from '@ionic-native/camera';
import {ImagePicker, ImagePickerOptions} from "@ionic-native/image-picker";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  private data;any;
  private profile:any;
  private usersList=[];
  private myimage:any='';
 private cameraOptions: CameraOptions = {
  quality: 100,
  encodingType: this.camera.EncodingType.JPEG,
  mediaType: this.camera.MediaType.PICTURE
  }
  private imageOption:ImagePickerOptions={
   quality:100,
    maximumImagesCount:1
  }

  constructor(public navCtrl: NavController,
              private webService:ServiceSingleton,
              public actionSheetCtrl: ActionSheetController,
              private imagePicker:ImagePicker,
              private camera:Camera) {
    this.webService.presentLoading();
    this.webService.postUserDetails().then((data)=>{
      this.webService.stopLoading();
      console.log(data);
      this.data=data;

      if(this.data && this.data.status==true) {
          this.profile=this.data.data[0];
          this.webService.profile=this.profile;
          if(this.data.data.length>1){
            this.data.data.forEach((data,index)=>{
                if(index>0){
                  this.usersList.push(data);
                }
            })
          }
      }
    });

  }
  uploadProfilePic(){
    console.log("upload pic");
    let actionSheet=this.actionSheetCtrl.create({
      title: 'Profile Photo',
      buttons: [
        {
          text: 'Upload Image',
          role: 'destructive',
          handler: () => {

            this.imagePicker.getPictures(this.imageOption).then(imagedata=>{
              this.myimage=imagedata;
            })

          }
        },{
          text: 'Open Camera',
          handler: () => {
            this.camera.getPicture(this.cameraOptions).then(imagedata=>{
              this.myimage=imagedata;
            })
          }
        },{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    actionSheet.present();

  }



}
