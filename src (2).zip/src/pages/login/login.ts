import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {ServiceSingleton} from "../../providers/service-singleton";
import {HomePage} from "../home/home";
import { SalesPage } from '../sales/sales';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  private data:any;
  private login={
    username:"",
    password:""
  }

  constructor(public navCtrl: NavController, public navParams: NavParams,private webService:ServiceSingleton) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }
  postlogin(){
    if(this.login.username==''){
      this.webService.presentAlert("Please Enter Username");
      return;
    }
    if(this.login.password==''){
      this.webService.presentAlert("Please Enter Password");
      return;
    }
    this.webService.presentLoading();
    this.webService.postLogin(this.login).then((data)=>{
      this.webService.stopLoading();
      if(data){
        this.data=data;
        if(this.data.status==true){
          this.webService.setToken(this.data.Token);
          this.webService.setUser(this.login.username);
          this.navCtrl.setRoot(SalesPage);
        }else{
          this.webService.presentAlert(this.data.message);
        }
      }
    })
  }
}
