import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {ServiceSingleton} from "../../providers/service-singleton";
import { MailComposerPage } from '../mail-composer/mail-composer';

/**
 * Generated class for the SalesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-sales',
  templateUrl: 'sales.html',
})
export class SalesPage {
  private data:any;
  private keys = [];
  private mailKeys=[];
  private SaleYear=[];
  private Banks=[];
  private saleno:any;
  private markedRows=[];
  private discount:boolean=false;
  private cumlative:number=0;
  private post={
    saleyear:"",
    saleno:"",
    username:""
  }
  constructor(public navCtrl: NavController,private webService:ServiceSingleton, public navParams: NavParams) {
      this.post.username=this.webService.getUser();
      this.getSaleYears();


  }
  getData(){
    this.post.saleno=this.saleno.split(" -")[0];
    console.log(this.post);
    this.webService.presentLoading();
    this.webService.postTeaSales(this.post).then((data:any)=>{
      this.webService.stopLoading();
      if(data && data.status==true){
      this.keys=Object.keys(data.data[0]);
      console.log(this.keys);
       this.data=data.data;
      }
    })
  }
  sendMail(){
    var myHtml='<table id="mytable"><tr class="row_hg">';
    this.keys.forEach((keys)=>{
      myHtml+='<th class="col_hg">'+keys+'</th>';
    });
    if(this.discount){
      console.log("hello")
      myHtml+='<th class="col_hg">DISCOUNT PAYED</th>';
    }
    myHtml+='</tr>';
    this.data.forEach((row)=>{
      if(row.selected) {

        myHtml += '<tr class="row_hg">';
        this.keys.forEach((keys) => {
          myHtml += '<td class="col_hg">' + this.parseFloat(row[keys]) + '</td>';
        });
        if (this.discount) {
          myHtml += '<td class="col_hg">' + this.parseFloat(row.PAYED - 0.1 * row.PAYED) + '</td>';
        }
        myHtml += '</tr>';
        if(this.discount){
          this.cumlative+=Number(row.PAYED - 0.1 * row.PAYED)
        }else{
          this.cumlative+=Number(row.PAYED)
        }
      }
    });
    myHtml+="</table>";
    console.log(this.cumlative);
    this.navCtrl.push(MailComposerPage,{body:myHtml,cum:this.cumlative,post:this.post});
  }
  getSaleYears(){
    this.webService.presentLoading();
    this.webService.getSaleYear().then((data:any)=>{
      this.webService.stopLoading();

      if(data && data.status==true){
         this.SaleYear=data.data;
      }
    });
  }


  parseFloat(num){
    if(isNaN(num)){
      return num;
    }else{
      return parseFloat(num).toFixed(2);
    }
  }
  rowMarked(row){
    if(!row.selected){
      row.selected=true;
    }else {
      row.selected = false;
    }
  }
  markAll(event){
    if(event){
      this.data.forEach((row)=>{
        row.selected=true;
      });
    }else{
      this.data.forEach((row)=>{
        row.selected=false;
      });
    }
  }

}
