import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { EmailComposer } from '@ionic-native/email-composer';
import {ServiceSingleton} from "../../providers/service-singleton";
import {MailBodyPage} from "../mail-body/mail-body";

@Component({
  selector: 'page-mail-composer',
  templateUrl: 'mail-composer.html',
})
export class MailComposerPage {
  private to:any;
  private cc:any;
  private subject:any;
  private body:any;
  private bankname:any;
  private Banks=[];
  private cum;
  private pay;
  private bal;
  private post:any;

  constructor(public navCtrl: NavController,private webService:ServiceSingleton,private emailComposer:EmailComposer, public navParams: NavParams) {
      this.body=this.navParams.get('body');
      this.cum=this.parseFloat(this.navParams.get("cum"));
      this.post=this.navParams.get("post");
      this.getBankList();
  }
  sendMail(){
    let email = {
      to: this.to,
      cc: this.cc,
      subject: this.subject,
      body: this.body,
      isHtml: true
    };

    // Send a text message using default options
    this.emailComposer.open(email);
  }
  updateBal(){
    this.bal=this.parseFloat(this.cum-this.pay);
  }
  parseFloat(num){
    if(isNaN(num)){
      return num;
    }else{
      return parseFloat(num).toFixed(2);
    }
  }
  getBankList(){
    this.webService.presentLoading();
    this.webService.getBankList().then((data:any)=>{
      this.webService.stopLoading();
      console.log(data);

      if(data && data.status==true){
        this.Banks=data.data;
      }
    });
  }
  mailBody(){
    var myHtml="";
    myHtml+="Buyer:<b>"+this.post.username+"</b><br>";
    myHtml+="Sale No:<b>"+this.post.saleno+"</b><br>";
    myHtml+="Sale Year:<b>"+this.post.saleyear+"</b><br>";
    myHtml+="Bank Name:<b>"+this.bankname+"</b><br>";
    myHtml+="Amount:<b>"+this.parseFloat(this.pay)+"</b><br>";
    myHtml+="Cum Proceeds:<b>"+this.cum+"</b><br>";
    myHtml+="Balance:<b>"+this.bal+"</b><br>";
    myHtml+="Refrence Details:<b>Bank Transfer</b><br><br>";
    myHtml+=this.body;
    this.navCtrl.push(MailBodyPage,{body:myHtml});
  }
}
