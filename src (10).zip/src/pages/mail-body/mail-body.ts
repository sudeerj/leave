import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {ServiceSingleton} from "../../providers/service-singleton";

@Component({
  selector: 'page-mail-body',
  templateUrl: 'mail-body.html',
})
export class MailBodyPage {
  private to;
  private subject;
  private body:any;
  private post:any;
  constructor(public navCtrl: NavController, private webService:ServiceSingleton,public navParams: NavParams) {
      this.body=this.navParams.get("body");
      this.post=this.navParams.get("post");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MailBodyPage');
  }
  sendMail(){
    var obj={
      to:this.to,
      subject:this.subject,
      from:this.webService.profile.Email,
      mailBody:this.body,
      username:this.post.username,
      saleno:this.post.saleno,
      saleyear:this.post.saleyear
    }
    this.webService.postEmail(obj);
  }
}
