import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { EmailComposer } from '@ionic-native/email-composer';
import {ServiceSingleton} from "../../providers/service-singleton";
import {MailBodyPage} from "../mail-body/mail-body";

@Component({
  selector: 'page-mail-composer',
  templateUrl: 'mail-composer.html',
})
export class MailComposerPage {
  private data:any=[];
  private keys = [];
  private mailKeys=[];
  private SaleYear=[];
  private Banks=[];
  private saleno:any;
  private markedRows=[];
  private discount:boolean=false;
  private cumlative:number=0;
  private bankname:any;
  private pay=0;
  private bal=0;
  private total=0;
  private rem_lot=0;
  private rem_pr=0;
  private sel_lot=0;
  private body;
  private post={
    saleyear:"",
    saleno:"",
    username:""
  }

  constructor(public navCtrl: NavController,private webService:ServiceSingleton,private emailComposer:EmailComposer, public navParams: NavParams) {

      this.data=this.navParams.get('data');
      this.keys=Object.keys(this.data[0]);
      this.data.forEach((data)=>{
        this.total+=Number(data.PROCEEDS);
        this.rem_pr+=Number(data.PROCEEDS);
        this.rem_lot++;
      });
      //this.cumlative=this.parseFloat(this.navParams.get("cum"));
      this.post=this.navParams.get("post");
      this.getBankList();
  }
  sendMail(){
    var myHtml='<table id="mytable"><tr class="row_hg">';
    this.keys.forEach((keys)=>{
      myHtml+='<th class="col_hg">'+keys+'</th>';
    });

    myHtml+='</tr>';
    this.data.forEach((row)=>{
      if(row.selected) {

        myHtml += '<tr class="row_hg">';
        this.keys.forEach((keys) => {
          myHtml += '<td class="col_hg">' + this.parseFloat(row[keys]) + '</td>';
        });
        myHtml += '</tr>';
      }
    });
    myHtml+="</table>";
    //console.log(this.cumlative);
    //this.navCtrl.push(MailComposerPage,{body:myHtml,cum:this.cumlative,post:this.post});
    this.body=myHtml;
    this.mailBody();
  }
  parseFloat(num){
    if(isNaN(num)){
      return num;
    }else{
     return Math.round(num);
      //return parseFloat(num).toFixed(2);
    }
  }
  rowMarked(row){
    if(!row.selected){
      row.selected=true;
      if(this.discount){
        row.TO_BE_PAY=Number(row.PROCEEDS - 0.1 * row.PROCEEDS);
        this.cumlative+=row.TO_BE_PAY;
        this.rem_pr-=Number(row.TO_BE_PAY);
      }else{
        row.TO_BE_PAY=row.PROCEEDS;
        this.cumlative+=Number(row.TO_BE_PAY);
        this.rem_pr-=Number(row.TO_BE_PAY);
      }
      this.sel_lot++;
      this.rem_lot--;
    }else {
      row.selected = false;
      this.cumlative-=Number(row.TO_BE_PAY)
      this.rem_pr+=Number(row.TO_BE_PAY);
      this.sel_lot--;
      this.rem_lot++;
    }
    this.updateBal();
  }
  markAll(event){

    if(event){
      this.data.forEach((row)=>{
        if(!row.selected){
          this.rowMarked(row);
        }
      });
    }else{
      this.data.forEach((row)=>{
        if(row.selected){
          this.rowMarked(row);
        }
      });
    }
  }
  getBankList(){
    this.webService.presentLoading();
    this.webService.getBankList().then((data:any)=>{
      this.webService.stopLoading();
      console.log(data);

      if(data && data.status==true){
        this.Banks=data.data;
      }
    });
  }
  mailBody(){
    var myHtml="";
    myHtml+="Buyer:<b>"+this.post.username+"</b><br>";
    myHtml+="Sale No:<b>"+this.post.saleno+"</b><br>";
    myHtml+="Sale Year:<b>"+this.post.saleyear+"</b><br>";
    myHtml+="Bank Name:<b>"+this.bankname+"</b><br>";
    myHtml+="Amount:<b>"+this.parseFloat(this.pay)+"</b><br>";
    myHtml+="Cum Proceeds:<b>"+this.parseFloat(this.cumlative)+"</b><br>";
    myHtml+="Balance:<b>"+this.bal+"</b><br>";
    myHtml+="Refrence Details:<b>Bank Transfer</b><br><br>";
    myHtml+=this.body;
    this.navCtrl.push(MailBodyPage,{body:myHtml,post:this.post});
  }
  updateBal(){
    this.bal=this.parseFloat(this.cumlative-this.pay);
  }
  updateCum(){

    this.data.forEach((row)=>{
      if(row.selected){
        if(this.discount){
          this.cumlative-=Number(row.TO_BE_PAY);
          this.rem_pr+=Number(row.TO_BE_PAY);
          row.TO_BE_PAY=Number(row.PROCEEDS - 0.1 * row.PROCEEDS);
          this.cumlative+=Number(row.TO_BE_PAY);
          this.rem_pr-=Number(row.TO_BE_PAY);

        }else{
          this.cumlative-=Number(row.TO_BE_PAY);
          this.rem_pr+=Number(row.TO_BE_PAY);
          row.TO_BE_PAY=row.PROCEEDS;

          this.cumlative+=Number(row.TO_BE_PAY);
          this.rem_pr-=Number(row.TO_BE_PAY);
        }
      }
    });
    this.updateBal();
  }
}
