import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {ServiceSingleton} from "../../providers/service-singleton";
import { MailComposerPage } from '../mail-composer/mail-composer';

/**
 * Generated class for the SalesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-sales',
  templateUrl: 'sales.html',
})
export class SalesPage {
  private data:any;
  private keys = [];
  private mailKeys=[];
  private SaleYear=[];
  private Banks=[];

  private post={
    saleyear:"",
    saleno:"",
    username:""
  }
  constructor(public navCtrl: NavController,private webService:ServiceSingleton, public navParams: NavParams) {
      this.post.username=this.webService.getUser();  
      this.getSaleYears();
      this.getBankList();

  }
  getData(){
    this.post.saleno=this.post.saleno.split("-")[0];
    console.log(this.post);
    this.webService.presentLoading();
    this.webService.postTeaSales(this.post).then((data:any)=>{
      this.webService.stopLoading();
      if(data && data.status==true){
      this.keys=Object.keys(data.data[0]);
      console.log(this.keys);
       this.data=data.data;
      }
    })
  }
  sendMail(){
    var myHtml='<table><tr>';
    this.mailKeys.forEach((keys)=>{
      myHtml+='<th>'+keys+'</th>';
    });
    myHtml+='</tr>';
    this.data.forEach((row)=>{
      myHtml+='<tr>';
      this.mailKeys.forEach((keys)=>{
        myHtml+='<td>'+row[keys]+'</td>';
      });
      myHtml+='</tr>'
    });

    this.navCtrl.push(MailComposerPage,{body:myHtml});
  }
  getSaleYears(){
    this.webService.getSaleYear().then((data:any)=>{
      console.log(data);
      
      if(data && data.status==true){
         this.SaleYear=data.data;
      }
    });    
  }
  
  getBankList(){
    this.webService.getBankList().then((data:any)=>{
      console.log(data); 
      
      if(data && data.status==true){
        this.Banks=data.data;
      }
    });    
  }

}
