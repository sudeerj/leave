using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;

namespace BuyersProfile
{
    public partial class FormFront : Form
    {
        DataTable dtMain = new DataTable();
        data da = new data();

        public FormFront()
        {
            InitializeComponent();
        }
        string connString, query;

        string DATE1 = Convert.ToString(System.DateTime.Now.Month);
        string DATE2 = Convert.ToString(System.DateTime.Now.Year);
        string DATE3 = Convert.ToString(System.DateTime.Now.Day);
        //string DATE1 = "1";



        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            ////check_offercount();
            //string str = dg.DataMember.ToString();
            //ExportImport exim = new ExportImport(str);
            //System.Data.DataSet ds = (System.Data.DataSet)dg.DataSource;
            //exim.setSource(ds);
            //exim.executeExport(txtSaleNo.Text);
            //exim.Show();
            //// record();
            ExportToExcel();
        }

        public void record()
        {
            //string FILENAME = (DATE1 + "-" + DATE2 + "-" + DATE3);
            string FILENAME = (DATE1 + 1);


            FileStream fs = File.Create(FILENAME);
            fs.Close();
            File.SetAttributes(
               FILENAME,
               FileAttributes.Archive |
               FileAttributes.Hidden |
               FileAttributes.ReadOnly
               );
        }

        private bool check_offercount()
        {
            string filePath = Application.StartupPath + DATE1 + "-" + DATE2 + "-" + DATE3;
            if (File.Exists(filePath))
                return true;
            else
            {
                return false;
            }
        }

        public void show_Grid(string saleyear, string saleno, DateTime datereceived, string catfrom, string catto, string status1, string status2, string batchfrom, string batchto)
        {
            OleDbConnection conn = null;
            OleDbDataAdapter da = null;
            //string Ecode = 0;
            //DateTime fromdate ;
            //DateTime todate;
            //if (string.TryParse(txtEstateCode.Text, out Ecode) && DateTime.TryParse(calFrom.Value, out fromdate) && DateTime.TryParse(calTo.Value, out todate))
            //{

            connString = "Provider=MSDAORA;Data Source=test;Persist Security Info=True;Password=ta3;User ID=t3";
            try
            {
                conn = new OleDbConnection(connString);
                //query = "select  IM.Invoice_no Inv,  im.estate_code ||decode(Im.mark_code,'*', ' ',IM.mark_code) Mark, id.actual_sale_year,id.actual_sale_no, id.grade_code,ID.ESTATE_CODE,id.actual_sale_year,id.actual_sale_no,id.no_of_chests,( id.No_of_Chests - nvl(id.sample_chests_total,0)) chests_main, id.sequence_no,id.sample_chests_total  sample_chests,  id.chest_weight, id.chest_weight_left  chest_weight_left,  id.manufact_date, im.date_received, id.chest_type, id.net_weight, id.gross_weight,  id.category_code,   id.category_code, em.selling_Mark,    s.address_Line1 ||  S.Address_line2 addr ,  S.ST_ADD, DECODE( S.store_code, NULL, NULL, ' ( '||S.store_code||' )' )st_code, DECODE( Id.pack_code,'BAGS',' Paper', ID.pack_code) pack_code,  id.pack_code pack_real,  ID.sample_allow, DECODE(IM.new_old, 'N', '2013', '2012') New, DECODE(ID.Catalogue_count, 0, ' ' , 'R') Reprint,  ID.catalogue_count,  id.ex_reprints, id.status, DECODE(ID.des_code, 'C', 'CLEANED', NULL) DES,  ID.is_overstuff " +
                //    "from invoice_master IM, Invoice_detail ID, estate_marks EM, Estates E, Stores S, Elevations EL, Sub_elevation SE " +
                //            "where     ID.estate_code = '" + Ecode + "' " +
                //            "and id.actual_sale_year = '" + saleyear + "'  " +
                //            "and id.actual_sale_no = '" + saleno + "'  " +
                //            "and im.date_received = '" + daterecived + "'  " +
                //            "and ID.grade_code = '" + gradecode + "'  " +
                //            "and IM.store_code = '" + storcode + "'  " +
                //            "and im.date_received = '" + daterecived + "'  " +
                //            "and ID.grade_code = '" + gradecode + "'  " +
                //            "and E.District_code = '" + discode + "'  " +
                //            "and IM.sale_type = '" + saletype + "'  " +
                //            "and ID.category_code between '" + catcodefrom + "' and  '" + catcodeto + "' " +

                //            "and EL.elevation_code between '" + elevationcode + "'  " +
                //            "and id.status = '" + status1 + "'  " +
                //            "and id.status = '" + status2 + "'  " +
                //            "and IM.batch_no between '" + batch1 + "' and '" + batch2 + "' " +
                //            "and  im.Invoice_no = id.invoice_no " +
                //            "and im.invoice_date = id.invoice_date " +
                //            "and im.estate_code = id.estate_code " +
                //            "and IM.estate_code = em.estate_code " +
                //            "and IM.mark_code = em.Mark_code " +
                //            "and im.estate_code = E.estate_code " +
                //            "and Im.store_code = s.store_code(+) " +
                //            "and E.sub_elevation_code = SE.sub_elevation_code " +
                //            "and SE.elevation_code = EL.elevation_code " +
                //            "order by  id.category_code,  id.sequence_no, ID.ESTATE_CODE ";


                query = "select 'W'BROKER, id.actual_sale_year SALEYEAR,id.actual_sale_no SALENO,im.date_received DATE_RECEIVED,ID.ESTATE_CODE MFCODE,em.selling_Mark SELLING_MARK,IM.Invoice_no Inv,id.grade_code GRADE,id.no_of_chests NO_OF_CHESTS,id.chest_weight CHEST_WEIGHT,id.gross_weight GROSS_WEIGHT,id.net_weight NET,id.category_code CATEGORY,s.address_Line1 ||  S.Address_line2 STORES " +
                    "from invoice_master IM, Invoice_detail ID, estate_marks EM, Estates E, Stores S, Elevations EL, Sub_elevation SE " +
                            "where  id.actual_sale_year = " + saleyear + " " +
                            "and id.actual_sale_no = " + saleno + " " +
                            "and im.date_received = '" + datereceived.ToString("dd-MMM-yyyy") + "' " +
                    //"and ID.grade_code = ALL  " +
                    //"and IM.store_code = ALL  " +
                    //"and E.District_code = ALL  " +
                    //"and IM.sale_type = ALL  " +
                            "and ID.category_code between '" + catfrom + "' and '" + catto + "' " +

                            //"and EL.elevation_code = ALL  " +
                            "and id.status IN('" + status1 + "','" + status2 + "')  " +

                            "and IM.batch_no between '" + batchfrom + "' and '" + batchto + "' " +
                            "and  im.Invoice_no = id.invoice_no " +
                            "and im.invoice_date = id.invoice_date " +
                            "and im.estate_code = id.estate_code " +
                            "and IM.estate_code = em.estate_code " +
                            "and IM.mark_code = em.Mark_code " +
                            "and im.estate_code = E.estate_code " +
                            "and Im.store_code = s.store_code(+) " +
                            "and E.sub_elevation_code = SE.sub_elevation_code " +
                            "and SE.elevation_code = EL.elevation_code " +
                    //"AND ID.SEQUENCE_NO > 2056093" +
                            "order by  id.category_code,  id.sequence_no, ID.ESTATE_CODE ";

                Console.WriteLine(query);
                conn.Open();
                da = new OleDbDataAdapter(query, conn);
                da.Fill(dataSet1, "BF");
                dg.SetDataBinding(dataSet1, "BF");
                dg.Refresh();
                MessageBox.Show("SuccessFull", "Offering", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                conn.Close();
            }

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (chbAll.Checked == true)
            {
                show_GridAll(txtSaleYear.Text, txtSaleNo.Text, txtCatFrom.Text, txtCatTo.Text, txtStatus1.Text, txtStatus2.Text, txtBatchFrom.Text, txtBatchTo.Text);
            }
            else
            {
                show_Grid(txtSaleYear.Text, txtSaleNo.Text, calFrom.Value, txtCatFrom.Text, txtCatTo.Text, txtStatus1.Text, txtStatus2.Text, txtBatchFrom.Text, txtBatchTo.Text);
            }
        }

        //else
        //{
        //     MessageBox.Show("Please Enter an Integer Value", "Buyers 10%", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //     txtEstateCode.Text="";

        //}

        private void ExportToExcel()
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application xlApp=new Microsoft.Office.Interop.Excel.Application();
            System.Data.DataSet ds = (System.Data.DataSet)dg.DataSource;

                string type=dg.DataMember.ToString();
                string col1 = "";
                int excount = 0;
                int hmcount = 0;
                int lfcount = 0;
                int tpcount = 0;
                int prcount = 0;
                int ofcount = 0;
                int oneacount = 0;
                int duscount = 0;
                int totcatcount = 0;
                double exnet = 0;
                double hmnet = 0;
                double lfnet = 0;
                double tpnet = 0;
                double prnet = 0;
                double ofnet = 0;
                double oneanet = 0;
                double dusnet = 0;
                double totnet = 0;
                string cat = "";
                string table_no = type;
                col1 = "JOHN KEY. - DAILY COLLECTION LIST FOR SALE " + txtSaleNo.Text;

                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;

                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                #region Actual Data
                System.Data.DataRowCollection dr = ds.Tables[table_no].Rows;
                int cols = ds.Tables[table_no].Columns.Count;

                xlWorkSheet.Cells[1, 1] = col1;
                for (int i = 0; i < cols; i++)
                {
                    col1 = ds.Tables[table_no].Columns[i].ColumnName;
                    xlWorkSheet.Cells[3, i + 1] = col1;
                }

                int num = dr.Count;
                for (int i = 0; i < num; i++)
                {
                    object[] array = dr[i].ItemArray;

                    cat = array[12].ToString();
                    if (cat == "10")
                    {
                        string extempqty = array[11].ToString();
                        exnet = exnet + Convert.ToDouble(extempqty);
                        excount = excount + 1;
                    }
                    if (cat == "20")
                    {
                        string hmtempqty = array[11].ToString();
                        hmnet = hmnet + Convert.ToDouble(hmtempqty);
                        hmcount = hmcount + 1;
                    }
                    if (cat == "30")
                    {
                        string lftempqty = array[11].ToString();
                        lfnet = lfnet + Convert.ToDouble(lftempqty);
                        lfcount = lfcount + 1;
                    }
                    if (cat == "35")
                    {
                        string tptempqty = array[11].ToString();
                        tpnet = tpnet + Convert.ToDouble(tptempqty);
                        tpcount = tpcount + 1;
                    }
                    if (cat == "36")
                    {
                        string prtempqty = array[11].ToString();
                        prnet = prnet + Convert.ToDouble(prtempqty);
                        prcount = prcount + 1;
                    }
                    if (cat == "40")
                    {
                        string oftempqty = array[11].ToString();
                        ofnet = ofnet + Convert.ToDouble(oftempqty);
                        ofcount = ofcount + 1;
                    }
                    if (cat == "45")
                    {
                        string oneatempqty = array[11].ToString();
                        oneanet = oneanet + Convert.ToDouble(oneatempqty);
                        oneacount = oneacount + 1;
                    }
                    if (cat == "50")
                    {
                        string dustempqty = array[11].ToString();
                        dusnet = dusnet + Convert.ToDouble(dustempqty);
                        duscount = duscount + 1;
                    }
                    totcatcount = excount + hmcount + lfcount + tpcount + prcount + ofcount + oneacount + duscount;
                    totnet = exnet + hmnet + lfnet + tpnet + prnet + ofnet + oneanet + dusnet;


                    int j;
                    for (j = 0; j < array.Length; j++)
                    {
                        col1 = array[j].ToString();
                        //if (i == hmcount)
                        //{
                        //    xlWorkSheet.Cells[i + 4, hmcount] = null;
                        //    xlWorkSheet.Cells[i + 4, 11] = hmcount;
                        //    xlWorkSheet.Cells[i + 4, 12] = hmnet;
                        //    xlWorkSheet.Cells[i + 4, 7] = "NO OF LOTS";
                        //}
                        //else if (hmcount == totcatcount - 1 && i == lfcount)
                        //{
                        //    xlWorkSheet.Cells[i + 4, lfcount] = null;
                        //}
                        //else
                        //{

                        xlWorkSheet.Cells[i + 4, j + 1] = col1;
                        //}

                    }

                }
                if (excount != 0)
                {
                    xlWorkSheet.Cells[num + 8, 4] = "EX-ESTATE NO OF LOTS";
                    xlWorkSheet.Cells[num + 8, 10] = excount;
                    xlWorkSheet.Cells[num + 8, 12] = exnet;
                }

                xlWorkSheet.Cells[num + 10, 4] = "HIGH and MEDIUM NO OF LOTS";
                xlWorkSheet.Cells[num + 10, 10] = hmcount;
                xlWorkSheet.Cells[num + 10, 12] = hmnet;

                xlWorkSheet.Cells[num + 12, 4] = "LOW GROWN - LEAFY GRADE NO OF LOTS";
                xlWorkSheet.Cells[num + 12, 10] = lfcount;
                xlWorkSheet.Cells[num + 12, 12] = lfnet;

                xlWorkSheet.Cells[num + 14, 4] = "TIPPY/ SMALL LEAF NO OF LOTS";
                xlWorkSheet.Cells[num + 14, 10] = tpcount;
                xlWorkSheet.Cells[num + 14, 12] = tpnet;

                xlWorkSheet.Cells[num + 16, 4] = "PREMIUM FLOWERY NO OF LOTS";
                xlWorkSheet.Cells[num + 16, 10] = prcount;
                xlWorkSheet.Cells[num + 16, 12] = prnet;

                xlWorkSheet.Cells[num + 18, 4] = "OFF GRADE NO OF LOTS";
                xlWorkSheet.Cells[num + 18, 10] = ofcount;
                xlWorkSheet.Cells[num + 18, 12] = ofnet;

                xlWorkSheet.Cells[num + 20, 4] = "BOP1A NO OF LOTS";
                xlWorkSheet.Cells[num + 20, 10] = oneacount;
                xlWorkSheet.Cells[num + 20, 12] = oneanet;

                xlWorkSheet.Cells[num + 22, 4] = "DUST NO OF LOTS";
                xlWorkSheet.Cells[num + 22, 10] = duscount;
                xlWorkSheet.Cells[num + 22, 12] = dusnet;

                xlWorkSheet.Cells[num + 24, 4] = "TOTAL LOTS";
                xlWorkSheet.Cells[num + 24, 10] = totcatcount;
                xlWorkSheet.Cells[num + 24, 12] = totnet;
                #endregion

                #region Dummy Data
                //xlWorkSheet.Cells[1, 1] = "ID";
                //xlWorkSheet.Cells[1, 2] = "Name";
                //xlWorkSheet.Cells[2, 1] = "1";
                //xlWorkSheet.Cells[2, 2] = "One";
                //xlWorkSheet.Cells[3, 1] = "2";
                //xlWorkSheet.Cells[3, 2] = "Two"; 
                #endregion
                string excelName = "C:\\BuyersProfile_ExportData_" + DateTime.Now.ToString("yyyyMMddHHmmssfff") +".xls";
                xlWorkBook.SaveAs(excelName, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(xlApp);

                MessageBox.Show("Data Exported Successfully.");


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Exporting : \n" + ex.ToString());
            }

        }


        public void show_GridAll(string saleyear, string saleno, string catfrom, string catto, string status1, string status2, string batchfrom, string batchto)
        {
            OleDbConnection conn = null;
            OleDbDataAdapter da = null;
            //string Ecode = 0;
            //DateTime fromdate ;
            //DateTime todate;
            //if (string.TryParse(txtEstateCode.Text, out Ecode) && DateTime.TryParse(calFrom.Value, out fromdate) && DateTime.TryParse(calTo.Value, out todate))
            //{

            connString = "Provider=MSDAORA;Data Source=test;Persist Security Info=True;Password=ta3;User ID=ta3";
            try
            {
                conn = new OleDbConnection(connString);
                //query = "select  IM.Invoice_no Inv,  im.estate_code ||decode(Im.mark_code,'*', ' ',IM.mark_code) Mark, id.actual_sale_year,id.actual_sale_no, id.grade_code,ID.ESTATE_CODE,id.actual_sale_year,id.actual_sale_no,id.no_of_chests,( id.No_of_Chests - nvl(id.sample_chests_total,0)) chests_main, id.sequence_no,id.sample_chests_total  sample_chests,  id.chest_weight, id.chest_weight_left  chest_weight_left,  id.manufact_date, im.date_received, id.chest_type, id.net_weight, id.gross_weight,  id.category_code,   id.category_code, em.selling_Mark,    s.address_Line1 ||  S.Address_line2 addr ,  S.ST_ADD, DECODE( S.store_code, NULL, NULL, ' ( '||S.store_code||' )' )st_code, DECODE( Id.pack_code,'BAGS',' Paper', ID.pack_code) pack_code,  id.pack_code pack_real,  ID.sample_allow, DECODE(IM.new_old, 'N', '2013', '2012') New, DECODE(ID.Catalogue_count, 0, ' ' , 'R') Reprint,  ID.catalogue_count,  id.ex_reprints, id.status, DECODE(ID.des_code, 'C', 'CLEANED', NULL) DES,  ID.is_overstuff " +
                //    "from invoice_master IM, Invoice_detail ID, estate_marks EM, Estates E, Stores S, Elevations EL, Sub_elevation SE " +
                //            "where     ID.estate_code = '" + Ecode + "' " +
                //            "and id.actual_sale_year = '" + saleyear + "'  " +
                //            "and id.actual_sale_no = '" + saleno + "'  " +
                //            "and im.date_received = '" + daterecived + "'  " +
                //            "and ID.grade_code = '" + gradecode + "'  " +
                //            "and IM.store_code = '" + storcode + "'  " +
                //            "and im.date_received = '" + daterecived + "'  " +
                //            "and ID.grade_code = '" + gradecode + "'  " +
                //            "and E.District_code = '" + discode + "'  " +
                //            "and IM.sale_type = '" + saletype + "'  " +
                //            "and ID.category_code between '" + catcodefrom + "' and  '" + catcodeto + "' " +

                //            "and EL.elevation_code between '" + elevationcode + "'  " +
                //            "and id.status = '" + status1 + "'  " +
                //            "and id.status = '" + status2 + "'  " +
                //            "and IM.batch_no between '" + batch1 + "' and '" + batch2 + "' " +
                //            "and  im.Invoice_no = id.invoice_no " +
                //            "and im.invoice_date = id.invoice_date " +
                //            "and im.estate_code = id.estate_code " +
                //            "and IM.estate_code = em.estate_code " +
                //            "and IM.mark_code = em.Mark_code " +
                //            "and im.estate_code = E.estate_code " +
                //            "and Im.store_code = s.store_code(+) " +
                //            "and E.sub_elevation_code = SE.sub_elevation_code " +
                //            "and SE.elevation_code = EL.elevation_code " +
                //            "order by  id.category_code,  id.sequence_no, ID.ESTATE_CODE ";


                query = "select 'F'BROKER, id.actual_sale_year SALEYEAR,id.actual_sale_no SALENO,im.date_received DATE_RECEIVED,ID.ESTATE_CODE MFCODE,em.selling_Mark SELLING_MARK,IM.Invoice_no Inv,id.grade_code GRADE,id.no_of_chests NO_OF_CHESTS,id.chest_weight CHEST_WEIGHT,id.gross_weight GROSS_WEIGHT,id.net_weight NET,id.category_code CATEGORY,s.address_Line1 ||  S.Address_line2 STORES " +
                    "from invoice_master IM, Invoice_detail ID, estate_marks EM, Estates E, Stores S, Elevations EL, Sub_elevation SE " +
                            "where  id.actual_sale_year = " + saleyear + " " +
                            "and id.actual_sale_no = " + saleno + " " +
                    //"and im.date_received = '" + datereceived.ToString("dd-MMM-yyyy") + "' " +
                    //"and ID.grade_code = ALL  " +
                    //"and IM.store_code = ALL  " +
                    //"and E.District_code = ALL  " +
                    //"and IM.sale_type = ALL  " +
                            "and ID.category_code between '" + catfrom + "' and '" + catto + "' " +

                            //"and EL.elevation_code = ALL  " +
                            "and id.status IN('" + status1 + "','" + status2 + "')  " +

                            "and IM.batch_no between '" + batchfrom + "' and '" + batchto + "' " +
                            "and  im.Invoice_no = id.invoice_no " +
                            "and im.invoice_date = id.invoice_date " +
                            "and im.estate_code = id.estate_code " +
                            "and IM.estate_code = em.estate_code " +
                            "and IM.mark_code = em.Mark_code " +
                            "and im.estate_code = E.estate_code " +
                            "and Im.store_code = s.store_code(+) " +
                            "and E.sub_elevation_code = SE.sub_elevation_code " +
                            "and SE.elevation_code = EL.elevation_code " +
                            "order by  id.category_code,  id.sequence_no, ID.ESTATE_CODE ";

                Console.WriteLine(query);
                conn.Open();
                da = new OleDbDataAdapter(query, conn);
                da.Fill(dataSet1, "BF");
                dg.SetDataBinding(dataSet1, "BF");
                dg.Refresh();
                MessageBox.Show("SuccessFull", "Offering", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                conn.Close();
            }

        }

        private void chbAll_CheckedChanged(object sender, EventArgs e)
        {
            if (chbAll.Checked == true)
            {
                calFrom.Enabled = false;
            }
            else
            {
                calFrom.Enabled = true;
            }
        }

        private void btnfinalize_Click(object sender, EventArgs e)
        {
            data da = new data();
            if (chbAll.Checked == true)
            {
                update(dtMain = update_GridAll(txtSaleYear.Text, txtSaleNo.Text, txtCatFrom.Text, txtCatTo.Text, txtStatus1.Text, txtStatus2.Text, txtBatchFrom.Text, txtBatchTo.Text));


            }
            else
            {
                update(dtMain = update_Grid(txtSaleYear.Text, txtSaleNo.Text, calFrom.Value, txtCatFrom.Text, txtCatTo.Text, txtStatus1.Text, txtStatus2.Text, txtBatchFrom.Text, txtBatchTo.Text));











            }
        }



        public DataTable update_GridAll(string saleyear, string saleno, string catfrom, string catto, string status1, string status2, string batchfrom, string batchto)
        {
            string query = "select 'FW'BROKER, id.actual_sale_year SALEYEAR,id.actual_sale_no SALENO,(to_char(im.date_received,'DD-MON-YYYY')) DATE_RECEIVED,ID.ESTATE_CODE MFCODE,em.selling_Mark SELLING_MARK,IM.Invoice_no Inv,id.grade_code GRADE,id.no_of_chests NO_OF_CHESTS,id.chest_weight CHEST_WEIGHT,id.gross_weight GROSS_WEIGHT,id.net_weight NET,id.category_code CATEGORY,s.address_Line1 ||  S.Address_line2 STORES " +
                    "from invoice_master IM, Invoice_detail ID, estate_marks EM, Estates E, Stores S, Elevations EL, Sub_elevation SE " +
                            "where  id.actual_sale_year = " + saleyear + " " +
                            "and id.actual_sale_no = " + saleno + " " +

                            "and ID.category_code between '" + catfrom + "' and '" + catto + "' " +


                            "and id.status IN('" + status1 + "','" + status2 + "')  " +

                            "and IM.batch_no between '" + batchfrom + "' and '" + batchto + "' " +
                            "and  im.Invoice_no = id.invoice_no " +
                            "and im.invoice_date = id.invoice_date " +
                            "and im.estate_code = id.estate_code " +
                            "and IM.estate_code = em.estate_code " +
                            "and IM.mark_code = em.Mark_code " +
                            "and im.estate_code = E.estate_code " +
                            "and Im.store_code = s.store_code(+) " +
                            "and E.sub_elevation_code = SE.sub_elevation_code " +
                            "and SE.elevation_code = EL.elevation_code " +
                            "order by  id.category_code,  id.sequence_no, ID.ESTATE_CODE ";

            dtMain = da.getTables(query);

            return dtMain;

        }


        public DataTable update_Grid(string saleyear, string saleno, DateTime datereceived, string catfrom, string catto, string status1, string status2, string batchfrom, string batchto)
        {
            string query = "select 'F'BROKER, id.actual_sale_year SALEYEAR,id.actual_sale_no SALENO,(to_char(im.date_received,'DD-MON-YYYY')) DATE_RECEIVED,ID.ESTATE_CODE MFCODE,em.selling_Mark SELLING_MARK,IM.Invoice_no Inv,id.grade_code GRADE,id.no_of_chests NO_OF_CHESTS,id.chest_weight CHEST_WEIGHT,id.gross_weight GROSS_WEIGHT,id.net_weight NET,id.category_code CATEGORY,s.address_Line1 ||  S.Address_line2 STORES " +
                        "from invoice_master IM, Invoice_detail ID, estate_marks EM, Estates E, Stores S, Elevations EL, Sub_elevation SE " +
                                "where  id.actual_sale_year = " + saleyear + " " +
                                "and id.actual_sale_no = " + saleno + " " +
                                "and im.date_received = '" + datereceived.ToString("dd-MMM-yyyy") + "' " +

                                "and ID.category_code between '" + catfrom + "' and '" + catto + "' " +


                                "and id.status IN('" + status1 + "','" + status2 + "')  " +

                                "and IM.batch_no between '" + batchfrom + "' and '" + batchto + "' " +
                                "and  im.Invoice_no = id.invoice_no " +
                                "and im.invoice_date = id.invoice_date " +
                                "and im.estate_code = id.estate_code " +
                                "and IM.estate_code = em.estate_code " +
                                "and IM.mark_code = em.Mark_code " +
                                "and im.estate_code = E.estate_code " +
                                "and Im.store_code = s.store_code(+) " +
                                "and E.sub_elevation_code = SE.sub_elevation_code " +
                                "and SE.elevation_code = EL.elevation_code " +
                //"AND ID.SEQUENCE_NO > 2056093" +
                                "order by  id.category_code,  id.sequence_no, ID.ESTATE_CODE ";

            dtMain = da.getTables(query);

            return dtMain;

        }

        public void update(DataTable dtMain)
        {

            if (dtMain.Rows.Count > 0)
            {
                for (int y = 0; y < dtMain.Rows.Count; y++)
                {
                    String upY = "update Invoice_detail set OFFERED = 'Y',offerd_sale = " + txtSaleNo.Text + " where Invoice_no = '" + dtMain.Rows[y]["INV"].ToString() + "'and actual_sale_year ='" + dtMain.Rows[y]["SALEYEAR"].ToString() + "' and actual_sale_no = '" + dtMain.Rows[y]["SALENO"].ToString() + "' and category_code = '" + dtMain.Rows[y]["CATEGORY"].ToString() + "' and estate_code = '" + dtMain.Rows[y]["MFCODE"].ToString() + "'";

                    da.insert(upY);

                }
                MessageBox.Show("Offering is Finalized..!", "Offering", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }





    }
}