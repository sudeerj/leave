namespace BuyersProfile
{
    partial class FormFront
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.dg = new System.Windows.Forms.DataGrid();
            this.txtSaleYear = new System.Windows.Forms.TextBox();
            this.dataSet1 = new System.Data.DataSet();
            this.BF = new System.Data.DataTable();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.calFrom = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSaleNo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCatFrom = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCatTo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBatchFrom = new System.Windows.Forms.TextBox();
            this.txtBatchTo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtStatus2 = new System.Windows.Forms.TextBox();
            this.txtStatus1 = new System.Windows.Forms.TextBox();
            this.chbAll = new System.Windows.Forms.CheckBox();
            this.btnfinalize = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BF)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonCancel
            // 
            this.buttonCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCancel.Location = new System.Drawing.Point(422, 175);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(88, 24);
            this.buttonCancel.TabIndex = 11;
            this.buttonCancel.Text = "Exit";
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdd.Location = new System.Drawing.Point(359, 12);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(88, 24);
            this.buttonAdd.TabIndex = 9;
            this.buttonAdd.Text = "&ADD";
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // btnExport
            // 
            this.btnExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.Location = new System.Drawing.Point(359, 70);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(88, 24);
            this.btnExport.TabIndex = 10;
            this.btnExport.Text = "Export";
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // dg
            // 
            this.dg.BackgroundColor = System.Drawing.Color.White;
            this.dg.DataMember = "";
            this.dg.GridLineColor = System.Drawing.Color.Blue;
            this.dg.HeaderBackColor = System.Drawing.Color.White;
            this.dg.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dg.Location = new System.Drawing.Point(12, 205);
            this.dg.Name = "dg";
            this.dg.Size = new System.Drawing.Size(498, 86);
            this.dg.TabIndex = 11;
            // 
            // txtSaleYear
            // 
            this.txtSaleYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSaleYear.Location = new System.Drawing.Point(128, 6);
            this.txtSaleYear.Name = "txtSaleYear";
            this.txtSaleYear.Size = new System.Drawing.Size(75, 21);
            this.txtSaleYear.TabIndex = 0;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "NewDataSet";
            this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
            this.BF});
            // 
            // BF
            // 
            this.BF.TableName = "BF";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Date Received";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Sale Year";
            // 
            // calFrom
            // 
            this.calFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.calFrom.Location = new System.Drawing.Point(128, 64);
            this.calFrom.Name = "calFrom";
            this.calFrom.Size = new System.Drawing.Size(89, 21);
            this.calFrom.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "Sale No";
            // 
            // txtSaleNo
            // 
            this.txtSaleNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSaleNo.Location = new System.Drawing.Point(128, 34);
            this.txtSaleNo.Name = "txtSaleNo";
            this.txtSaleNo.Size = new System.Drawing.Size(75, 21);
            this.txtSaleNo.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "Category Code";
            // 
            // txtCatFrom
            // 
            this.txtCatFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCatFrom.Location = new System.Drawing.Point(147, 96);
            this.txtCatFrom.Name = "txtCatFrom";
            this.txtCatFrom.Size = new System.Drawing.Size(56, 21);
            this.txtCatFrom.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(153, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 15);
            this.label5.TabIndex = 13;
            this.label5.Text = "From";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(250, 150);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "To";
            // 
            // txtCatTo
            // 
            this.txtCatTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCatTo.Location = new System.Drawing.Point(236, 96);
            this.txtCatTo.Name = "txtCatTo";
            this.txtCatTo.Size = new System.Drawing.Size(56, 21);
            this.txtCatTo.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 15);
            this.label7.TabIndex = 16;
            this.label7.Text = "Batch No";
            // 
            // txtBatchFrom
            // 
            this.txtBatchFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBatchFrom.Location = new System.Drawing.Point(147, 168);
            this.txtBatchFrom.Name = "txtBatchFrom";
            this.txtBatchFrom.Size = new System.Drawing.Size(56, 21);
            this.txtBatchFrom.TabIndex = 7;
            // 
            // txtBatchTo
            // 
            this.txtBatchTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBatchTo.Location = new System.Drawing.Point(236, 168);
            this.txtBatchTo.Name = "txtBatchTo";
            this.txtBatchTo.Size = new System.Drawing.Size(56, 21);
            this.txtBatchTo.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(25, 132);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 15);
            this.label8.TabIndex = 17;
            this.label8.Text = "Status";
            // 
            // txtStatus2
            // 
            this.txtStatus2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus2.Location = new System.Drawing.Point(236, 126);
            this.txtStatus2.Name = "txtStatus2";
            this.txtStatus2.Size = new System.Drawing.Size(56, 21);
            this.txtStatus2.TabIndex = 6;
            // 
            // txtStatus1
            // 
            this.txtStatus1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus1.Location = new System.Drawing.Point(147, 126);
            this.txtStatus1.Name = "txtStatus1";
            this.txtStatus1.Size = new System.Drawing.Size(56, 21);
            this.txtStatus1.TabIndex = 5;
            // 
            // chbAll
            // 
            this.chbAll.AutoSize = true;
            this.chbAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbAll.Location = new System.Drawing.Point(223, 68);
            this.chbAll.Name = "chbAll";
            this.chbAll.Size = new System.Drawing.Size(48, 17);
            this.chbAll.TabIndex = 18;
            this.chbAll.Text = "ALL";
            this.chbAll.UseVisualStyleBackColor = true;
            this.chbAll.CheckedChanged += new System.EventHandler(this.chbAll_CheckedChanged);
            // 
            // btnfinalize
            // 
            this.btnfinalize.BackColor = System.Drawing.Color.Orange;
            this.btnfinalize.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfinalize.ForeColor = System.Drawing.Color.Black;
            this.btnfinalize.Location = new System.Drawing.Point(338, 126);
            this.btnfinalize.Name = "btnfinalize";
            this.btnfinalize.Size = new System.Drawing.Size(135, 30);
            this.btnfinalize.TabIndex = 19;
            this.btnfinalize.Text = "Finalize Offering";
            this.btnfinalize.UseVisualStyleBackColor = false;
            this.btnfinalize.Click += new System.EventHandler(this.btnfinalize_Click);
            // 
            // FormFront
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkKhaki;
            this.ClientSize = new System.Drawing.Size(522, 303);
            this.Controls.Add(this.btnfinalize);
            this.Controls.Add(this.chbAll);
            this.Controls.Add(this.txtStatus2);
            this.Controls.Add(this.txtStatus1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtBatchTo);
            this.Controls.Add(this.txtBatchFrom);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtCatTo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtCatFrom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSaleNo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.calFrom);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSaleYear);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.dg);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(530, 330);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(530, 330);
            this.Name = "FormFront";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Offering";
            ((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BF)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.DataGrid dg;
        private System.Windows.Forms.TextBox txtSaleYear;
        private System.Data.DataSet dataSet1;
        private System.Data.DataTable BF;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker calFrom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSaleNo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCatFrom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCatTo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBatchFrom;
        private System.Windows.Forms.TextBox txtBatchTo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtStatus2;
        private System.Windows.Forms.TextBox txtStatus1;
        private System.Windows.Forms.CheckBox chbAll;
        private System.Windows.Forms.Button btnfinalize;
    }
}

