using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data.SqlClient ;


namespace BuyersProfile
{
	/// <summary>
	/// Summary description for ExportImport.
	/// </summary>
	public class ExportImport : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		string type;
        //private AxOWC10.AxSpreadsheet ExcelControl1;

        private Microsoft.Office.Interop.Excel.Application ExcelControl1;
        
		System.Data.DataSet ds;
		public ExportImport(string str)
		{
			//
			// Required for Windows Form Designer support
			//
			type=str;
		
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExportImport));
            this.ExcelControl1 = new Microsoft.Office.Interop.Excel.Application();
            //((System.ComponentModel.ISupportInitialize)(this.ExcelControl1)).BeginInit();
            this.SuspendLayout();
            // 
            // ExcelControl1
            // 
            //this.ExcelControl1.DataSource = null;
            //this.ExcelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            //this.ExcelControl1.Enabled = true;
            //this.ExcelControl1.Location = new System.Drawing.Point(0, 0);
            //this.ExcelControl1.Name = "ExcelControl1";
            //this.ExcelControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("ExcelControl1.OcxState")));
            //this.ExcelControl1.Size = new System.Drawing.Size(714, 454);
            //this.ExcelControl1.TabIndex = 0;
            //// 
            //// ExportImport
            //// 
            //this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            //this.ClientSize = new System.Drawing.Size(714, 454);
            //this.Controls.Add(this.ExcelControl1);
            //this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            //this.Name = "ExportImport";
            //this.ShowInTaskbar = false;
            //this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            //this.Text = "Export Import Wizard";
            //((System.ComponentModel.ISupportInitialize)(this.ExcelControl1)).EndInit();
            //this.ResumeLayout(false);

		}
		#endregion

		public void setSource(System.Data.DataSet ds_temp)
		{
			ds=ds_temp;
			
		}

		public void executeExport(string saleno)
		{
			string col1="";
            int excount = 0;
            int hmcount = 0;
            int lfcount = 0;
            int tpcount = 0;
            int prcount = 0;
            int ofcount = 0;
            int oneacount = 0;
            int duscount = 0;
            int totcatcount = 0;
            double exnet = 0;
            double hmnet = 0;
            double lfnet = 0;
            double tpnet = 0;
            double prnet = 0;
            double ofnet = 0;
            double oneanet = 0;
            double dusnet = 0;
            double totnet = 0;
            string cat = "";
			string table_no=type;
            col1 = "JOHN KEY. - DAILY COLLECTION LIST FOR SALE " + saleno;
			System.Data.DataRowCollection dr=ds.Tables[table_no].Rows;
			int cols=ds.Tables[table_no].Columns.Count; 

			ExcelControl1.Cells[1,1]=col1;
			for(int i=0;i<cols;i++)
			{
				col1=ds.Tables[table_no].Columns[i].ColumnName ; 
				ExcelControl1.Cells[3,i+1]=col1; 
			}
			
			int num=dr.Count; 
			for(int i=0 ;i<num ; i++)
			{
				object[] array=dr[i].ItemArray ;

                cat = array[12].ToString();
                if (cat == "10")
                {
                    string extempqty = array[11].ToString();
                    exnet = exnet + Convert.ToDouble(extempqty);
                    excount = excount + 1;
                }
                if (cat == "20")
                {
                    string hmtempqty = array[11].ToString();
                    hmnet = hmnet + Convert.ToDouble(hmtempqty);
                    hmcount = hmcount + 1;
                }
                if (cat == "30")
                {
                    string lftempqty = array[11].ToString();
                    lfnet = lfnet + Convert.ToDouble(lftempqty);
                    lfcount = lfcount + 1;
                }
                if (cat == "35")
                {
                    string tptempqty = array[11].ToString();
                    tpnet = tpnet + Convert.ToDouble(tptempqty);
                    tpcount = tpcount + 1;
                }
                if (cat == "36")
                {
                    string prtempqty = array[11].ToString();
                    prnet = prnet + Convert.ToDouble(prtempqty);
                    prcount = prcount + 1;
                }
                if (cat == "40")
                {
                    string oftempqty = array[11].ToString();
                    ofnet = ofnet + Convert.ToDouble(oftempqty);
                    ofcount = ofcount + 1;
                }
                if (cat == "45")
                {
                    string oneatempqty = array[11].ToString();
                    oneanet = oneanet + Convert.ToDouble(oneatempqty);
                    oneacount = oneacount + 1;
                }
                if (cat == "50")
                {
                    string dustempqty = array[11].ToString();
                    dusnet = dusnet + Convert.ToDouble(dustempqty);
                    duscount = duscount + 1;
                }
                totcatcount = excount + hmcount + lfcount + tpcount + prcount + ofcount + oneacount + duscount;
                totnet = exnet + hmnet + lfnet + tpnet + prnet + ofnet + oneanet + dusnet;


				int j;
				for(j=0;j<array.Length ;j++)
				{
					col1=array[j].ToString();
                    //if (i == hmcount)
                    //{
                    //    ExcelControl1.Cells[i + 4, hmcount] = null;
                    //    ExcelControl1.Cells[i + 4, 11] = hmcount;
                    //    ExcelControl1.Cells[i + 4, 12] = hmnet;
                    //    ExcelControl1.Cells[i + 4, 7] = "NO OF LOTS";
                    //}
                    //else if (hmcount == totcatcount - 1 && i == lfcount)
                    //{
                    //    ExcelControl1.Cells[i + 4, lfcount] = null;
                    //}
                    //else
                    //{

                        ExcelControl1.Cells[i + 4, j + 1] = col1;
                    //}
					
				}
						
			}
            if (excount != 0)
            {
                ExcelControl1.Cells[num + 8, 4] = "EX-ESTATE NO OF LOTS";
                ExcelControl1.Cells[num + 8, 10] = excount;
                ExcelControl1.Cells[num + 8, 12] = exnet;
            }

            ExcelControl1.Cells[num + 10, 4] = "HIGH and MEDIUM NO OF LOTS";
            ExcelControl1.Cells[num + 10, 10] = hmcount;
            ExcelControl1.Cells[num + 10, 12] = hmnet;

            ExcelControl1.Cells[num + 12, 4] = "LOW GROWN - LEAFY GRADE NO OF LOTS";
            ExcelControl1.Cells[num + 12, 10] = lfcount;
            ExcelControl1.Cells[num + 12, 12] = lfnet;

            ExcelControl1.Cells[num + 14, 4] = "TIPPY/ SMALL LEAF NO OF LOTS";
            ExcelControl1.Cells[num + 14, 10] = tpcount;
            ExcelControl1.Cells[num + 14, 12] = tpnet;

            ExcelControl1.Cells[num + 16, 4] = "PREMIUM FLOWERY NO OF LOTS";
            ExcelControl1.Cells[num + 16, 10] = prcount;
            ExcelControl1.Cells[num + 16, 12] = prnet;

            ExcelControl1.Cells[num + 18, 4] = "OFF GRADE NO OF LOTS";
            ExcelControl1.Cells[num + 18, 10] = ofcount;
            ExcelControl1.Cells[num + 18, 12] = ofnet;

            ExcelControl1.Cells[num + 20, 4] = "BOP1A NO OF LOTS";
            ExcelControl1.Cells[num + 20, 10] = oneacount;
            ExcelControl1.Cells[num + 20, 12] = oneanet;

            ExcelControl1.Cells[num + 22, 4] = "DUST NO OF LOTS";
            ExcelControl1.Cells[num + 22, 10] = duscount;
            ExcelControl1.Cells[num + 22, 12] = dusnet;

            ExcelControl1.Cells[num + 24, 4] = "TOTAL LOTS";
            ExcelControl1.Cells[num + 24, 10] = totcatcount;
            ExcelControl1.Cells[num + 24, 12] = totnet;
            
		}
		

	
	}
}
