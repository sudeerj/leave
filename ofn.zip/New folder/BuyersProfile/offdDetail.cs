﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuyersProfile
{
    class offdDetail
    {
        public string broker { get; set; }
        public string saleYear { get; set; }
        public string saleNo { get; set; }
        public DateTime recevedate { get; set; }
        
    }
}
