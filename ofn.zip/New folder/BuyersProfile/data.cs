﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using System.Data;

namespace BuyersProfile
{
    class data
    {
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataAdapter adapter;

        private void DBCreate()
        {
            try
            {
                String connectionstring = "Provider=MSDAORA;Data Source=test;Password=ta3;User ID=ta3";
                conn.ConnectionString = connectionstring;
                conn.Open();
                cmd.Connection = conn;
            }
            catch (InvalidCastException e)
            {
                throw (e);
            }
        }


        public System.Data.DataTable getTables(string oldb)
        {
            try
            {
                DBCreate();
                adapter = new OleDbDataAdapter(oldb, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }



        //public DataTable update_GridAll(string saleyear, string saleno, string catfrom, string catto, string status1, string status2, string batchfrom, string batchto)
        //{
        //    DataTable dtMain = new DataTable();

        //}

               






        public void insert(string qry)
        {
            this.DBCreate();
            cmd = new OleDbCommand(qry, conn);
            cmd.ExecuteNonQuery();
            conn.Close();

        }


    }
}
