import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {ServiceSingleton} from "../../providers/service-singleton";

@Component({
  selector: 'page-mail-body',
  templateUrl: 'mail-body.html',
})
export class MailBodyPage {
  private to;
  private subject;
  private body:any;
  private post:any;
  constructor(public navCtrl: NavController, private webService:ServiceSingleton,public navParams: NavParams) {
      this.body=this.navParams.get("body");
      this.post=this.navParams.get("post");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MailBodyPage');
  }
  sendMail(){
    this.post.to_email=this.to;
    this.post.subject=this.subject;
    console.log(JSON.stringify(this.post));
    this.webService.presentLoading();
    this.webService.postEmail(this.post).then((data)=>{
      this.webService.stopLoading();
      console.log(data);
    });
  }
}
