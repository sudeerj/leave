import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { EmailComposer } from '@ionic-native/email-composer';

@Component({
  selector: 'page-mail-composer',
  templateUrl: 'mail-composer.html',
})
export class MailComposerPage {
  private to:any;
  private cc:any;
  private subject:any;
  private body:any;

  constructor(public navCtrl: NavController,private emailComposer:EmailComposer, public navParams: NavParams) {
      this.body=this.navParams.get('body');
  }
  sendMail(){
    let email = {
      to: this.to,
      cc: this.cc,
      subject: this.subject,
      body: this.body,
      isHtml: true
    };
    
    // Send a text message using default options
    this.emailComposer.open(email);
  }
}
