import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {ServiceSingleton} from "../../providers/service-singleton";
import { MailComposerPage } from '../mail-composer/mail-composer';

import {RootData} from "@angular/core/src/view";

/**
 * Generated class for the SalesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-sales',
  templateUrl: 'sales.html',
})
export class SalesPage {
  private data:any;
  private keys = [];
  private mailKeys=[];
  private SaleYear=[];
  private Banks=[];
  private saleno:any;
  private markedRows=[];
  private discount:boolean=false;
  private cumlative:number=0;
  private bankname:any;
  private pay=0;
  private bal=0;
  private total=0;
  private rem_lot=0;
  private rem_pr=0;
  private sel_lot=0;
  private tenapply=0;
  private body;
  private post={
    saleyear:"2018",
    saleno:"",
    username:""
  }
  constructor(public navCtrl: NavController,private webService:ServiceSingleton, public navParams: NavParams) {
     
    this.post.username=this.webService.getUser();
      this.getSaleYears();
     


  }




  
  getData(){
    this.post.saleno=this.saleno.split(" -")[0];
    console.log(this.post);
    this.webService.presentLoading();
    this.webService.postTeaSales(this.post).then((data:any)=>{
      this.webService.stopLoading();
      if(data && data.status==true){
      this.keys=Object.keys(data.data[0]);
      console.log(this.keys);
       this.data=data.data;
      this.getTenApp();

      }
    })
  }
  sendMail(){
    var myHtml='<table id="mytable"><tr class="row_hg">';
    this.keys.forEach((keys)=>{
      myHtml+='<th class="col_hg">'+keys+'</th>';
    });

    myHtml+='</tr>';
    this.data.forEach((row)=>{
      if(row.selected) {

        myHtml += '<tr class="row_hg">';
        this.keys.forEach((keys) => {
          myHtml += '<td class="col_hg">' + this.parseFloat(row[keys]) + '</td>';
        });
        myHtml += '</tr>';
      }
    });
    myHtml+="</table>";
    //console.log(this.cumlative);
    //this.navCtrl.push(MailComposerPage,{body:myHtml,cum:this.cumlative,post:this.post});
    this.body=myHtml;
    this.mailBody();
  }
  getSaleYears(){
    this.webService.presentLoading();
    this.webService.getSaleYear().then((data:any)=>{
      this.webService.stopLoading();
      this.getBankList();
      if(data && data.status==true){
         this.SaleYear=data.data;
console.log(this.SaleYear);
      }
    });
  }

 




  parseFloat(num){
    if(isNaN(num)){
      return num;
    }else{
      return parseFloat(num).toFixed(0);
    }
  }






  /*rowMarked(row){
    if(!row.selected){
      row.selected=true;
      if(this.discount){
        row.PAYED=Number(row.PROCEEDS - 0.1 * row.PROCEEDS);
        this.cumlative+=row.PAYED;
      }else{
        row.PAYED=row.PROCEEDS;
this.cumlative+=Number(row.TO_BE_PAY)
      }
    }else {
      row.selected = false;
this.cumlative-=Number(row.TO_BE_PAY)
    }
    this.updateBal();
  }*/

/*
rowMarked(row){
    if(!row.selected){
      row.selected=true;
      if(this.discount){
        row.TO_BE_PAY=Number(row.PROCEEDS - 0.1 * row.PROCEEDS);
      
this.cumlative+=row.TO_BE_PAY;
      }else{
        row.TO_BE_PAY=row.PROCEEDS;
 this.cumlative+=Number(row.TO_BE_PAY);
        this.rem_pr-=Number(row.TO_BE_PAY);
      }
      this.sel_lot++;
      this.rem_lot--;
    }else {
      row.selected = false;


      this.cumlative-=Number(row.TO_BE_PAY)
      this.rem_pr+=Number(row.TO_BE_PAY);
      this.sel_lot--;
      this.rem_lot++;
    }
    this.updateBal();
  }
*/
rowMarked(row){
    if(!row.selected){
      row.selected=true;
      if(this.discount){
        row.TO_BE_PAY=Number(row.PROCEEDS - 0.1 * row.PROCEEDS);
        this.cumlative+=row.TO_BE_PAY;
        this.rem_pr-=Number(row.TO_BE_PAY);
      }else{
        row.TO_BE_PAY=row.PROCEEDS;
        this.cumlative+=Number(row.TO_BE_PAY);
        this.rem_pr-=Number(row.TO_BE_PAY);
      }
      this.sel_lot++;
      this.rem_lot--;
    }else {
      row.selected = false;
      this.cumlative-=Number(row.TO_BE_PAY)
      this.rem_pr+=Number(row.TO_BE_PAY);
      this.sel_lot--;
      this.rem_lot++;
    }
    this.updateBal();
  }


/*

  markAll(event){

    if(event){
      this.data.forEach((row)=>{
        this.rowMarked(row);
      });
    }else{
      this.data.forEach((row)=>{
        this.rowMarked(row);
      });
    }
  }
*/
markAll(event){

    if(event){
      this.data.forEach((row)=>{
        if(!row.selected){
          this.rowMarked(row);
        }
      });
    }else{
      this.data.forEach((row)=>{
        if(row.selected){
          this.rowMarked(row);
        }
      });
    }
  }



  getBankList(){
    this.webService.presentLoading();
    this.webService.getBankList().then((data:any)=>{
      this.webService.stopLoading();
      console.log(data);

      if(data && data.status==true){
        this.Banks=data.data;

      }
    });
  }


getTenApp(){

console.log("hello");
this.keys=Object.keys(this.data[0]);

this.data.forEach((data)=>{
        this.total+=Number(data.PROCEEDS);
        this.rem_pr+=Number(data.PROCEEDS);
       this.rem_lot++;
      });

console.log(this.total);


}

  mailBody(){
    var myHtml="";
    myHtml+="Buyer:<b>"+this.post.username+"</b><br>";
    myHtml+="Sale No:<b>"+this.post.saleno+"</b><br>";
    myHtml+="Sale Year:<b>"+this.post.saleyear+"</b><br>";
    myHtml+="Bank Name:<b>"+this.bankname+"</b><br>";
    myHtml+="Amount:<b>"+this.parseFloat(this.pay)+"</b><br>";
    myHtml+="Cum Proceeds:<b>"+this.parseFloat(this.cumlative)+"</b><br>";
    myHtml+="Balance:<b>"+this.bal+"</b><br>";
    myHtml+="Refrence Details:<b>Bank Transfer</b><br><br>";
    myHtml+=this.body;
 //   this.navCtrl.push(MailBodyPage,{body:myHtml});
  }
  updateBal(){
    this.bal=this.parseFloat(this.cumlative-this.pay);
    console.log(this.bal);
  }



/*  updateCum(){
//row.selected=false;  

    this.data.forEach((row)=>{



            
       if(row.selected){
          if(this.discount){
          this.cumlative-=row.PAYED;
          row.PAYED=Number(row.PROCEEDS - 0.1 * row.PROCEEDS);
          this.cumlative+=row.PAYED;
        }else{
         // this.cumlative-=Number(row.PAYED);
          this.cumlative-=Number(row.TO_BE_PAY);
          row.PAYED=row.PROCEEDS;
        //  this.cumlative+=Number(row.PAYED)
     this.cumlative+=Number(row.TO_BE_PAY)
             }
   }

    });
    
    this.updateBal();
       }


*/

 updateCum(){

    this.data.forEach((row)=>{
      if(row.selected){
        if(this.discount){
      
          this.cumlative-=Number(row.TO_BE_PAY);
          this.rem_pr+=Number(row.TO_BE_PAY);
          row.TO_BE_PAY=Number(row.PROCEEDS - 0.1 * row.PROCEEDS);
      
          this.cumlative+=Number(row.TO_BE_PAY);
          this.rem_pr-=Number(row.TO_BE_PAY);

        }else{
        
         this.cumlative-=Number(row.TO_BE_PAY);
          this.rem_pr+=Number(row.TO_BE_PAY);
          row.TO_BE_PAY=row.PROCEEDS;
     
          this.cumlative+=Number(row.TO_BE_PAY);
          this.rem_pr-=Number(row.TO_BE_PAY);

        }
      }
    });
    this.updateBal();
  this.getTenApp();
  }




    }
