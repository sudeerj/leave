<?php


class Authors_model extends CI_Model {

    /**
     * Constructor
     *
     */

    function __Construct()
    {
        parent::__Construct();
    }


    // --------------------------------------------------------------------

    /**
     * Get Authors
     *
     * @access	private
     * @param	array	conditions to fetch data
     * @return	object	object with result set
     */
    function getUsers($conditions=array(),$fields='')
    {

        parent::__construct();


        if(count($conditions)>0)
            $this->db->where($conditions);
        $this->db->where('id !=',1);
        $this->db->from('admin_user');

        $this->db->order_by("admin_user.id", "asc");


        if($fields!='')
            $this->db->select($fields);
        else
            $this->db->select('*');

        $result = $this->db->get();

        return $result;


    }//End of getUsers Function

    /**
     * This function is used to get the author listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function userListingCount($searchText = '')
    {
        $this->db->select('id');
        $this->db->from('admin_user as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.username  LIKE '%".$searchText."%'
                            OR  BaseTbl.full_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('id !=',1);
        $this->db->where('status !=',3);
        $query = $this->db->get();

        return count($query->result());
    }

    /**
     * This function is used to get the author listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function userListing($searchText = '', $page, $segment)
    {
        $this->db->select('*');
        $this->db->from('admin_user as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.username  LIKE '%".$searchText."%'
                            OR  BaseTbl.full_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('id !=',1);
        $this->db->where('status !=',3);
        $this->db->limit($page, $segment);
        $query = $this->db->get();

        $result = $query->result();
        return $result;
    }
    /**
     * This function is used to delete the author information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteUser($userId, $userInfo)
    {
        $this->db->where('id', $userId);
        $this->db->update('admin_user', $userInfo);

        return $this->db->affected_rows();
    }
    /**
     * This function used to get author information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getUserInfo($userId)
    {
        $this->db->select('*');
        $this->db->from('admin_user');
        $this->db->where('id !=',1);
        $this->db->where('status !=', 3);
        $this->db->where('id', $userId);
        $query = $this->db->get();

        return $query->result();
    }

    /**
     * This function is used to update the author information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function editUser($userInfo, $userId)
    {
        $this->db->where('id', $userId);
        $this->db->update('admin_user', $userInfo);

        return TRUE;
    }
}