<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Constant_model extends CI_Model
{
    public function __construct()
    {
        // Call the Model constructor
        parent::__construct();
        $this->load->database();
    }

    // Query Data from Table with Order;
    public function getDataAll($table, $order_column, $order_type,$where='')
    {
        if($where!=''){
            $this->db->where($where)->order_by("$order_column", "$order_type");
        }else {
            $this->db->order_by("$order_column", "$order_type");
        }
        $query = $this->db->get("$table");
        //print_r($query);
        $result = $query->result();
        $this->db->save_queries = false;        
        //$this->output->enable_profiler(TRUE);

        return $result;
    }
     public function getDataWhere($table,$where='')
    {
        if($where!=''){
            $this->db->where($where);
        } 
        $query = $this->db->get("$table");
        $result = $query->result_array();
        $this->db->save_queries = false;

        return $result;
    }
    public function getddData($table,$key,$name, $order_column,$where='')
    {
        $this->db->select("$key,$name")->order_by("$order_column", "ASC");
        if($where!=''){
                    $query = $this->db->where($where)->get("$table");

        } else {
                    $query = $this->db->get("$table");

        }
        $result = $query->result();
        $array = array();
        for($i=0;$i<count($result);$i++){
            $key_data= $result[$i]->$key;
            $name_data= $result[$i]->$name;
          $array[$key_data]   = $name_data;
        }
          //$this->output->enable_profiler(TRUE);

        return $array;
    }
    public function getDataCSV($table,$name, $where='',$order_column='')
    {
        if($order_column !=''){
            $this->db->select("$name");
        } else {
            $this->db->select("$name");
        
        }
        if($where!=''){
                    $query = $this->db->where($where)->get("$table");

        } else {
                    $query = $this->db->get("$table");

        }
        $result = $query->result();
        $array = array();
        for($i=0;$i<count($result);$i++){
            $name_data= $result[$i]->$name;
            if(!in_array($name_data, $array)){
                $array[][]   = $name_data;
            }
        }
        return implode(' , ',$array);
    }
    //getDataCSV
    // Query Data from Table by One Columns;
    public function getDataOneColumn($table, $col1_name, $col1_value)
    {
        $this->db->where("$col1_name", $col1_value);

        $query = $this->db->get("$table");
        $result = $query->result();
        $this->db->save_queries = false;

        return $result;
    }

    // Query Data from Table By two columns;
    public function getDataTwoColumn($table, $col1_name, $col1_value, $col2_name, $col2_value)
    {
        $this->db->where("$col1_name", $col1_value);
        $this->db->where("$col2_name", $col2_value);

        $query = $this->db->get("$table");
        $result = $query->result();
        $this->db->save_queries = false;

        return $result;
    }

    // Query Data from Table by One Columns and Sort;
    public function getDataOneColumnSortColumn($table, $col1_name, $col1_value, $sort_column, $sort_type)
    {
        $this->db->where("$col1_name", $col1_value);

        $this->db->order_by("$sort_column", "$sort_type");
        $query = $this->db->get("$table");
        $result = $query->result();
        $this->db->save_queries = false;

        return $result;
    }

    // Query Data from Table by One Columns and Sort;
    public function getDataTwoColumnSortColumn($table, $col1_name, $col1_value, $col2_name, $col2_value, $sort_column, $sort_type)
    {
        $this->db->where("$col1_name", $col1_value);
        $this->db->where("$col2_name", $col2_value);

        $this->db->order_by("$sort_column", "$sort_type");
        $query = $this->db->get("$table");
        $result = $query->result();
        $this->db->save_queries = false;

        return $result;
    }

    // Not Equal To;
    public function twoColumnNotEqual($table, $col1_name, $col1_value, $col2_name, $col2_value)
    {
        $this->db->where("$col1_name", $col1_value);
        $this->db->where("$col2_name != ", $col2_value);

        $query = $this->db->get("$table");
        $result = $query->result();
        $this->db->save_queries = false;

        return $result;
    }

    // Insert Data to Any Table;
    public function insertData($table, $data)
    {
        return $this->db->insert("$table", $data);
    }
     public function record_count($table,$key)
    {
        $this->db->order_by($key, 'DESC');
        $query = $this->db->get($table);
        $this->db->save_queries = false;

        return $query->num_rows();
    }
    public function fetch_data($table,$key,$order,$limit, $start)
    {
        $this->db->order_by($key, $order);
        $this->db->limit($limit, $start);
        $query = $this->db->get($table);

        $result = $query->result();

        $this->db->save_queries = false;

        return $result;
    }
    // Insert Data to Any Table and get the last id;
    public function insertDataReturnLastId($table, $data)
    {
        $this->db->insert("$table", $data);

        return $this->db->insert_id();
    }

    // Update Data to Any Table;
    public function updateData_gold($table, $data, $id)
    {
        $this->db->where('gpro_id', $id);
        $this->db->update("$table", $data);

        return true;
    }


    public function updateData($table, $data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update("$table", $data);

        return true;
    }


 public function updateDatagold($table, $data, $id)
    {
        $this->db->where('gpro_id', $id);
        $this->db->update("$table", $data);

        return true;
    }

     function add_update($table,$where,$data){
         
        $records=  $this->db->where($where)->from($table)->count_all_results();
        if($records>0){
            $this->db->where($where);
             $this->db->update($table, $data);
        } else {
            $this->db->insert($table, $data);
         }
      // echo  $this->db->_error_message();
      //  echo $this->db->_error_number();
       // exit;
        return true;
            
    }
    function add_updatev2($table,$where,$data){
         $id=0;
        $records    =  $this->db->where($where)->from($table)->count_all_results();
        if($records>0){
            $this->db->where($where);
             $this->db->update($table, $data);
        } else {
            $this->db->insert($table, $data);
            $id = $this->db->insert_id();
        }
      // echo  $this->db->_error_message();
      //  echo $this->db->_error_number();
       // exit;
        return $id;
            
    }
    // Delete Data from Any Table;
    public function deleteData($table, $id,$column='')
    {
        if($column!=''){
                   $this->db->where($column, $id);
 
        } else {
                    $this->db->where('id', $id);

        }
        $this->db->delete("$table");

        return true;
    }




public function deleteData_gold($table, $id,$column='')
    {
        if($column!=''){
                   $this->db->where($column, $id);
 
        } else {
                    $this->db->where('gpro_id', $id);

        }
        $this->db->delete("$table");

        return true;
    }



    public function deleteByColumn($table, $col_name, $col_value)
    {
        $this->db->where("$col_name", $col_value);
        $this->db->delete("$table");

        return true;
    }
    public function getSingle($table,$select,$where,$field='',$order_by='',$sort=''){
            if($order_by!=''){
                $row = $this->db->select($select)->where($where)->order_by($order_by,$sort)->from($table)->get()->row();
            }else{
                $row = $this->db->select($select)->where($where)->from($table)->get()->row();
            }
            if(is_object($row)){
                if($field==''){$field=$select;}
                return $this->db->select($select)->where($where)->from($table)->get()->row()->$field;
            } else {return 0;}
    }
    public function getNextId($table,$is_outlet=0,$field=0){
        $arr=array();
        if($is_outlet==1){
            $outlets =  $this->Constant_model->getddData('outlets','id','name', 'id');
            foreach($outlets as $oid=>$val){
                $arr[$oid]= $this->db->select_max($field)->where('outlet_id='.$oid)->from($table)->get()->row()->sid;
            }

           return $arr;
        }else{
            return $this->db->query("SELECT AUTO_INCREMENT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA ='".$this->db->database."' AND TABLE_NAME = '".$table."'")->row()->AUTO_INCREMENT;
        }
    }
    
    public function addTransaction($payment){
         $tdata['user_id'] = $data['created_by']= $this->session->userdata('user_id');

    
            $tdata['amount'] = $payment['amount'];
            $tdata['outstanding']   = $payment['balance'];
            $tdata['transaction']   = lang('trans_ref').': '.$payment['reference_no'];//$payment['cheque_no'];
            $this->db->insert("transactions", $tdata);
            return $this->db->insert_id();



    }

}
