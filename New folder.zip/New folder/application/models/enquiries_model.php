<?php

class Enquiries_model extends CI_Model {

    /**
     * Constructor
     *
     */

    function __Construct()
    {
        parent::__Construct();
    }




    /**
     * This function is used to get the brand listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function userListingCount($searchText = '')
    {
        $this->db->select('id');
        $this->db->from(' enquiries as BaseTbl');
       /* if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.username  LIKE '%".$searchText."%'
                            OR  BaseTbl.name  LIKE '%".$searchText."%'
                            OR  BaseTbl.full_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }*/
        //$this->db->where('status',1);
        $query = $this->db->get();

        return count($query->result());
    }

    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function userListing($searchText = '', $page, $segment)
    {
        $this->db->select('*');
        $this->db->from('enquiries as BaseTbl');
        /*if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.username  LIKE '%".$searchText."%'
                            OR  BaseTbl.name  LIKE '%".$searchText."%'
                            OR  BaseTbl.full_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('status',1);*/
        $this->db->limit($page, $segment);
        $query = $this->db->get();

        $result = $query->result();
        return $result;
    }
    /**
     * This function is used to delete the user information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteBrand($userId, $userInfo)
    {
        $this->db->where('id', $userId);
        $this->db->update('brand', $userInfo);

        return $this->db->affected_rows();
    }
    /**
     * This function used to get brand information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getMessages($userId)
    {
        $this->db->select('author_messages.*,ci_users.full_name');
        $this->db->select_max('author_messages.id' , 'id');
        $this->db->select_max('author_messages.message' , 'message');
        $this->db->select_max('author_messages.author_id' , 'author_id');
        $this->db->select_max('author_messages.user_id' , 'user_id');
        $this->db->select_max('author_messages.sent' , 'sent');
        $this->db->join('ci_users','ci_users.user_id=author_messages.user_id');
        $this->db->from('author_messages');
        $this->db->where('author_id',$userId);
        $this->db->where('recd',0);
        $this->db->order_by('author_messages.id','DESC');
        $this->db->group_by('author_messages.user_id');

        $query = $this->db->get();

        return $query->result_array();
    }
    /**
     * This function used to get brand information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getMessagesuser($userId)
    {
        $this->db->select('author_messages.*,ci_users.full_name');
        $this->db->join('ci_users','ci_users.user_id=author_messages.user_id');
        $this->db->from('author_messages');
        $this->db->where('author_messages.author_id',$this->session->userdata('userId'));
        $this->db->where('author_messages.user_id',$userId);
        $this->db->order_by('author_messages.id','ASC');
        $query = $this->db->get();

        return $query->result_array();
    }
    /**
     * This function used to get brand information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getMessagesauthor()
    {
        $this->db->select('author_messages.*,ci_users.full_name');
        $this->db->join('ci_users','ci_users.user_id=author_messages.user_id');
        $this->db->from('author_messages');
        $this->db->where('author_messages.author_id',$this->session->userdata('brand_id'));
        $this->db->where('author_messages.user_id',$this->session->userdata('user_id'));
        $this->db->order_by('author_messages.id','ASC');
        $query = $this->db->get();

        return $query->result_array();
    }
    /**
     * This function used to get brand information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getBrandInfo($userId)
    {
        $this->db->select('*');
        $this->db->from('brand');
        $this->db->where('id', $userId);
        $query = $this->db->get();

        return $query->result();
    }
    /**
     * This function used to get brand information
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function checkBrandExists($userId)
    {
        $this->db->select('*');
        $this->db->from('brand');
        $this->db->where('name', $userId);
        $query = $this->db->get();

        return $query->result_array();
    }
    /**
     * This function used to get admin username
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function checkUsernameExists($userId)
    {
        $this->db->select('*');
        $this->db->from('brand');
        $this->db->where('username', $userId);
        $query = $this->db->get();

        return $query->result_array();
    }
    /**
     * This function is used to update the brand information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function editBrand($userInfo, $userId)
    {
        $this->db->where('id', $userId);
        $this->db->update('brand', $userInfo);

        return TRUE;
    }

}