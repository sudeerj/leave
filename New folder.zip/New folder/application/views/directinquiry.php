<!--banner-->
<div class="banner-top">
    <div class="container">
        <h2 class="animated wow fadeInLeft" data-wow-delay=".5s">Inquiry</h2>
        <div class="clearfix"> </div>
    </div>
</div>
<!--content-->
<div class="product">
    <div class="container">

        <div class="col-md-12 contact-grids1 animated wow fadeInRight" data-wow-delay=".5s">
            <form method="post" id="geninquiry" action="<?php echo base_url('site/sendinquiry');?>">
                <div class="contact-form2 form-item form-group">
                    <h4>Name</h4>

                    <input type="text" placeholder="" name="name">

                </div>


                <div class="contact-form2 form-item form-group">
                    <h4>Email</h4>

                    <input type="email" placeholder="" name="email">

                </div>

                <div class="contact-form2 form-item form-group">
                    <h4>Country</h4>

                    <select name="country" class="form-control">
                        <?php
                        foreach ($countries as $country){?>
                            <option value="<?php echo $country['id']?>"><?php echo $country['name']?></option>
                        <?php }
                        ?>

                    </select>

                </div>
                <div class="contact-form2 form-item form-group">
                    <h4>Business Type</h4>

                    <select name="businesstype" class="form-control">
                        <option value="1">Retail</option>
                        <option value="2">Wholesale</option>
                    </select>

                </div>

                <div class="contact-me form-item form-group">
                    <h4>Message</h4>

                    <textarea type="text" placeholder="" name="message" "> </textarea>
                </div>
                <input type="submit" value="Submit">
            </form>

        </div>
        <div class="clearfix"></div>
    </div>

    <div class="clearfix" style="margin-bottom: 50px;"></div>
    <!--//products-->

</div>
