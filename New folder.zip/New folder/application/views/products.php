<div class="banner-top">
    <div class="container">
        <h2 class="animated wow fadeInLeft" data-wow-delay=".5s">Products</h2>
        <div class="clearfix"> </div>
    </div>
</div>
<!--content-->
<div class="product">
    <div class="container">

        <div class="col-md-12 animated wow fadeInRight" data-wow-delay=".5s">
            <div class="mid-popular">
                <?php if(!empty($products)){
                   foreach ($products as $product){ ?>
                <div class="col-sm-4 item-grid item-gr  simpleCart_shelfItem">
                    <div class="grid-pro">
                        <div class="women">
                            <h6><a href="single.html"><?php echo $product['name']; ?></a></h6>
                           <p><b>SKU:</b>  <?php echo $product['product_sku']; ?></p>
                            <p><b>ManuFacturer:</b>  <?php echo $product['manuname']; ?></p>
                            <a href="<?php echo base_url('site/inquiry/'.$product['id'])?>" data-text="Inquiry" class="but-hover1 item_add">Inquiry</a>
                        </div>
                    </div>
                </div>
<?php }} ?>

                <div class="clearfix"></div>
            </div>
        </div>


    </div class="clearfix"></div>
</div>
</div>
