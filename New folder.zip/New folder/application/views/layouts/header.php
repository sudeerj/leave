<!DOCTYPE html>
    <html>
    <head>
        <title>Inquiry System</title>
        <!-- for-mobile-apps -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Classic Style Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <!-- //for-mobile-apps -->
        <link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css" media="all" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/formValidation.min.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
    baseURL = "<?php echo base_url(); ?>";

</script>
        <!-- cart -->
        <!-- for bootstrap working -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js//vendor/formvalidation/js/formValidation.min.js"></script>
        <script src="http://getbootstrap.com/2.3.2/assets/js/bootstrap.js"></script>

        <script src="<?php echo base_url(); ?>assets/js/vendor/formvalidation/js/framework/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/scripts.js" type="text/javascript"></script>
    </head>

    <body>
    <!-- header -->
    <div class="header">
        <div class="container">
            <div class="logo-nav">

                <nav class="navbar navbar-default">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header nav_2">
                        <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="navbar-brand logo-nav-left wow fadeInLeft animated" data-wow-delay=".5s">
                            <h1 class="animated wow pulse" data-wow-delay=".5s">
                                <a href="#">Inquiry<span>System</span></a></h1>
                        </div>

                    </div>
                    <div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
                        <ul class="nav navbar-nav">
                            <li <?php if($this->uri->segment(2)==''){?>class="active"<?php }?>><a href="<?php echo base_url();?>" class="act">Home</a></li>
                            <li <?php if($this->uri->segment(2)=='products'){?>class="active"<?php }?>><a href="<?php echo base_url() ?>site/products"> Products</a></li>
                            <li <?php if($this->uri->segment(2)=='inquiry'){?>class="active"<?php }?>><a href="<?php echo base_url() ?>site/inquiry">Inquiry</a></li>
                        </ul>
                    </div>
                </nav>
            </div>

        </div>
    </div>