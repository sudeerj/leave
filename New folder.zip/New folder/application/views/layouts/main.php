<?php $this->load->view('layouts/header');?>
<?php $this->load->view($page);?>
<?php $this->load->view('layouts/footer');?>
