
<div class="product">
    <div class="container">

        <div class="col-md-12 footer-top1">
            <h4 style="color: black">Welcome to Inquiry System. </h4>

        </div>
    </div class="clearfix"></div>
</div>