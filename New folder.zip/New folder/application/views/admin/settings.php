<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-gears"></i> Brand Name

      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Brand Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->

                    <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                        ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo $this->session->flashdata('error'); ?>
                        </div>
                    <?php } ?>
                    <?php
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                        ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo $this->session->flashdata('success'); ?>
                        </div>
                    <?php } ?>
                    <form role="form" id="addUser" action="<?php echo base_url() ?>admin/settings" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="brandname">Brand Name</label>
                                        <input type="text" class="form-control required" id="brandname" name="brandname" maxlength="128" value="<?php echo $this->session->userdata('brand');?>" disabled>
                                    </div>
                                    
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="brandname">Brand Logo</label>
                                        <input type="file" class="form-control required" id="logo" name="logo">
                                    </div>
<p style="color: red;">Please Upload logo Size of 161X72.</p>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-6">
<?php if(!empty($branddetails[0]->logo)){ ?>
    <img src="<?php echo base_url();?>uploads/<?php echo $branddetails[0]->logo;?>" height="200" width="200">
                                <?php } ?>
                            </div>
                                </div>

                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />

                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">

                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
