<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-gears"></i> Inquiries Management
            <small>Add, Edit, Delete</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">

            </div>

        </div>
        <?php if($this->session->flashdata('error')){?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $this->session->flashdata('error'); ?>
            </div>
        <?php }?>
        <?php
        $success = $this->session->flashdata('success');
        if($success)
        {
            ?>
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $this->session->flashdata('success'); ?>
            </div>
        <?php } ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Inquiries List</h3>
                        <div class="box-tools">
                           <!-- <form action="<?php /*echo base_url() */?>admin/enquiries/index" method="POST" id="searchList">
                                <div class="input-group">
                                    <input type="text" name="searchText" value="<?php /*//echo $searchText; */?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                                    <div class="input-group-btn">
                                        <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </form>-->
                        </div>
                    </div><!-- /.box-header -->
                    <div class="box-body table-responsive no-padding">
                        <table class="table table-hover">
                            <tr>
                                <th>Sr No.</th>
                                <th>Product</th>
                                <th>Product SKU</th>
                                <th>Email</th>
                                <th>Country</th>
                                <th>Created At</th>
                                <th class="text-center">Actions</th>
                            </tr>
                            <?php
                            if(!empty($inquiries))
                            {
                                $x =1;
                                foreach($inquiries as $record)
                                {
                                    ?>
                                    <tr>
                                        <td><?php echo $x++; ?></td>
                                        <td><?php echo $record['prodname']; ?></td>
                                        <td>
                                            <?php echo $record['product_sku'];?></td>
                                        <td><?php echo $record['email']; ?></td>
                                        <td><?php echo $record['cname']; ?></td>
                                        <td><?php echo date('d M Y',strtotime($record['created_at'])); ?></td>
                                        <td class="text-center">
                                            <a class="btn btn-sm btn-info" title="View" href="<?php echo base_url().'admin/inquiries/view/'.$record['id']; ?>"><i class="fa fa-eye"></i></a>

                                        </td>
                                    </tr>
                                    <?php
                                }
                            }else{
                                ?>
                                <tr><td>There is no data avaialable</td></tr>
                            <?php } ?>
                        </table>

                    </div><!-- /.box-body -->
                    <div class="box-footer clearfix">
                        <?php //echo $this->pagination->create_links(); ?>
                    </div>
                </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
</div>
