<!--banner-->
<div class="banner-top">
    <div class="container">
        <h2 class="animated wow fadeInLeft" data-wow-delay=".5s">Inquiry</h2>
        <div class="clearfix"> </div>
    </div>
</div>
<!--content-->
<div class="product">
    <div class="container">
<div class="col-md-6">
    <h3><?php echo $product[0]['name'];?></h3><br>
    <img src="<?php echo base_url()?>assets/images/no_image.jpg"><br>
    <p><label>ManuFacturer:</label>  <?php echo $product[0]['manuname'];?></p><br>
    <p><label>SKU:</label>  <?php echo $product[0]['product_sku'];?></p>
    
</div>
        <div class="col-md-6 contact-grids1 animated wow fadeInRight" data-wow-delay=".5s">
            <form id="inquiry" method="post" role="form" action="<?php echo base_url('site/addinquiry');?>">
                <input type="hidden" value="<?php echo $product[0]['id'];?>" name="product_id">
                <div class="contact-form2 form-item form-group">
                    <h4>Name</h4>

                    <input type="text" placeholder=""  name="name" id="name" class="form-control" required>

                </div>


                <div class="contact-form2 form-item form-group">
                    <h4>Email</h4>

                    <input type="email" placeholder=""  name="email" id="email" class="form-control">

                </div>
                <div class="contact-form2 form-item form-group">
                    <h4>Country</h4>

                   <select name="country" class="form-control">
                       <?php
                       foreach ($countries as $country){?>
                       <option value="<?php echo $country['id']?>"><?php echo $country['name']?></option>
                       <?php }
                       ?>

                   </select>

                </div>
                <div class="contact-form2 form-item form-group">
                    <h4>Business Type</h4>

                    <select name="businesstype" class="form-control">
                        <option value="1">Retail</option>
                        <option value="2">Wholesale</option>
                    </select>

                </div>



                <div class="contact-form2 form-item form-group">
                    <h4>Message</h4>

                    <textarea type="text"  placeholder=""  name="message" class="form-control"> </textarea>
                </div>
                
                <input type="submit" value="Submit" name="submit1">
            </form>

        </div>
        <div class="clearfix"></div>
    </div>

    <div class="clearfix" style="margin-bottom: 50px;"></div>
