<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Login (LoginController)
 * Login class to control to authenticate user credentials and starts user's session.
 * @author : sudeera
 * @version : 1.1
 * @since : 1/8/2017
 */
class Site extends CI_Controller
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('inquiries_model');
        $this->load->model('products_model');
    }

    public function index(){
        $data['page'] = 'home';
       $this->load->view('layouts/main',$data);
    }

    public function products(){
        $data['page'] = 'products';
        $data['products'] = $this->products_model->getProducts();
        $this->load->view('layouts/main',$data);
    }

    public function inquiry($id=''){
        if($id!='') {
            $data['page'] = 'inquiry';
            $data['countries'] = $this->inquiries_model->getCountries();
            $data['manufactures'] = $this->products_model->getManufacturer();
            $data['product'] = $this->products_model->getProducts();
            $this->load->view('layouts/main', $data);
        }else{
            $data['page'] = 'directinquiry';
            $data['countries'] = $this->inquiries_model->getCountries();
            $data['manufactures'] = $this->products_model->getManufacturer();
            $data['products'] = $this->products_model->getProducts();
            $this->load->view('layouts/main', $data);
        }
    }
    public function addinquiry(){
        if($_POST){
            $productdetail = $this->products_model->getProducts($_POST['product_id']);
            if(!empty($productdetail)) {
                $insertdata['name'] = $_POST['name'];
                $insertdata['email'] = $_POST['email'];
                $insertdata['country_id'] = $_POST['country'];
                $insertdata['business_type'] = $_POST['businesstype'];
                $insertdata['message'] = $_POST['message'];
                $insertdata['manufacturer_id'] = $productdetail[0]['manufacturer_id'];
                $insertdata['product_id '] =$_POST['product_id'];
                $insertdata['product_sku'] =$productdetail[0]['product_sku'];
                $insertdata['created_at'] = date('Y-m-d h:i:s');
                $insert = $this->db->insert('enquiries',$insertdata);
                if($insert){
                    $countrydetails = $this->inquiries_model->getCountries($_POST['country']);
                    $this->load->library('email');
                    $email_body ="<p>Hello Admin,</p><br><p>Please Find Following Inquiry Details :</p><br><p>
Customer Name : ".$_POST['name']."</p><br><p>
Customer Email : ".$_POST['email']."</p><br><p>
Product Name : ".$productdetail[0]['name']."</p><br><p>
Country : ".$countrydetails[0]['name']."</p><br><p>
Product SKU : ".$productdetail[0]['product_sku']."</p><br><p>
ManuFacturer : ".$productdetail[0]['manuname']."</p><br><p>
Message : ".$_POST['message']."</p><br><br><p>Thanks</p>";
                    $subject = 'Product Inquiry';
                    //$message = '<p>This message has been sent for testing purposes.</p>';

// Get full html:
                    $body = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=' . strtolower(config_item('charset')) . '" />
    <title>' . html_escape($subject) . '</title>
    <style type="text/css">
        body {
            font-family: Arial, Verdana, Helvetica, sans-serif;
            font-size: 16px;
        }
    </style>
</head>
<body>
' . $email_body . '
</body>
</html>';
                    $result = $this->email
                        ->from('noreply@gmail.com')
                        ->to('test@gmail.com')
                        ->subject($subject)
                        ->message($body)
                        ->send();


                    redirect('site/index');
                }else{
                    redirect('site/inquiry/'.$_POST['product_id']);
                }
            }else{
                redirect('site/index');
            }
        }
    }
    public function sendinquiry(){
        if($_POST){

                $insertdata['name'] = $_POST['name'];
                $insertdata['email'] = $_POST['email'];
                $insertdata['country_id'] = $_POST['country'];
                $insertdata['business_type'] = $_POST['businesstype'];
                $insertdata['message'] = $_POST['message'];
                $insertdata['created_at'] = date('Y-m-d h:i:s');
                $insert = $this->db->insert('enquiries',$insertdata);
                if($insert){
                    $this->load->library('email');
                    $email_body ="<p>Hello Admin,</p><br><p>".$_POST["name"]." have inquiries about ".$_POST['message']."</p><br><br><p>Thanks</p>";
                    $subject = 'General Inquiry';
                    //$message = '<p>This message has been sent for testing purposes.</p>';

// Get full html:
                    $body = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=' . strtolower(config_item('charset')) . '" />
    <title>' . html_escape($subject) . '</title>
    <style type="text/css">
        body {
            font-family: Arial, Verdana, Helvetica, sans-serif;
            font-size: 16px;
        }
    </style>
</head>
<body>
' . $email_body . '
</body>
</html>';
                    $result = $this->email
                        ->from('noreply@gmail.com')
                        ->to('test@gmail.com')
                        ->subject($subject)
                        ->message($body)
                        ->send();
                    redirect('site/index');
                }else{
                    redirect('site/inquiry');
                }

        }
    }
}


?>