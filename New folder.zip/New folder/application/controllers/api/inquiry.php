<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : sudeera
 * @version : 1.1
 * @since : 31/7/2017
 */
class Inquiry extends CI_Controller
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('inquiries_model');
        $this->load->model('products_model');
        //$this->load->model('user_model');
        //$this->isLoggedIn();

    }


    /**
     * This function is used to add inquiry
     */
    public function addNewInquiry()
    {

    if($_POST){
        if(!isset($_POST['name']) || $_POST['name']==''){
            echo json_encode(array('status'=>false,'message'=>'Please Enter Name.'));
            return;
        }
        if(!isset($_POST['email']) || $_POST['email']==''){
            echo json_encode(array('status'=>false,'message'=>'Please Enter Email.'));
            return;
        }
        if(!isset($_POST['country_id']) || $_POST['country_id']==''){
            echo json_encode(array('status'=>false,'message'=>'Please Select Country.'));
            return;
        }
        if(!isset($_POST['business_type']) || $_POST['business_type']==''){
            echo json_encode(array('status'=>false,'message'=>'Please Select Business type.'));
            return;
        }
        if(!isset($_POST['message']) || $_POST['message']==''){
            echo json_encode(array('status'=>false,'message'=>'Please Enter Message.'));
            return;
        }
        if(!isset($_POST['manufacturer_id']) || $_POST['manufacturer_id']==''){
            echo json_encode(array('status'=>false,'message'=>'Please Select Manufacturer.'));
            return;
        }
        $insertinquiry = $this->inquiries_model->insertInquiry();
        if($insertinquiry){
            echo json_encode(array('status'=>true,'message'=>'Inquiry added successfully.'));
        }else{
            echo json_encode(array('status'=>false,'message'=>'Something Went Wrong.Please try after sometimes.'));
        }
    }else{
        echo json_encode(array('status'=>false,'message'=>'Something Went Wrong.Please try after sometimes.'));
    }


    }
    /**
     * This function is used to get all countries
     */
    public function getCountries()
    {

        $result = $this->inquiries_model->getCountries();
        if(count($result)){
            echo json_encode(array('status'=>true,'message'=>'List of all Countries.','data'=>$result));
        }else{
            echo json_encode(array('status'=>false,'message'=>'No Countries Found.'));
        }



    }

    /**
     * This function is used to get all products
     */
    public function getProducts(){
        $result = $this->products_model->getProducts();
        if(count($result)){
            echo json_encode(array('status'=>true,'message'=>'List of all Products.','data'=>$result));
        }else{
            echo json_encode(array('status'=>false,'message'=>'No Products Found.'));
        }
    }

    /**
     * This function is used to get all products
     */
    public function getTypeOfBusiness(){

            echo json_encode(array('status'=>true,'data'=>array('1'=>'Retail','2'=>'Wholesale')));

    }
    /**
     * This function is used to get all products
     */
    public function getManufacturer(){
        $result = $this->products_model->getManufacturer();
        if(count($result)){
            echo json_encode(array('status'=>true,'message'=>'List of all Manufacturer.','data'=>$result));
        }else{
            echo json_encode(array('status'=>false,'message'=>'No Manufacturer Found.'));
        }
    }

}

?>