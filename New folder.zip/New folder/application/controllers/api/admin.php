<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

//require APPPATH . '/libraries/REST_Controller.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Sudeera
 * @version : 1.1
 * @since : 8/2/2017
 */
class Admin extends CI_Controller
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('login_model');
        $this->load->model('inquiries_model');
        //$this->load->model('blog_model');;
        //echo $this->uri->segment(3);exit;
        if($this->uri->segment(3)!='login') {
            $this->isLoggedIn();
        }

    }



    /**
     * This function is used to login admin
     */
    public function login()
    {
        if($_POST) {
            if(!isset($_POST['username']) || $_POST['username']==''){
                echo json_encode(array('status'=>false,'message'=>'Please Enter Username.'));
                return;
            }
            if(!isset($_POST['password']) || $_POST['password']==''){
                echo json_encode(array('status'=>false,'message'=>'Please Enter Password.'));
                return;
            }
            $username = $_POST['username'];
            $password = $_POST['password'];
            $result = $this->login_model->loginMe($username, $password);
            if (count($result) > 0) {
                $token = md5(uniqid($result['id'], true));
                $update = $this->db->where('id',$result['id'])->update('admin_user',array('token'=>$token));
                if($update) {
                    echo json_encode(array('status' => true,'token'=>$token));
                }else{
                    echo json_encode(array('status'=>false,'message'=>'Incorrect Username or Password'));
                }
            }else{
                echo json_encode(array('status'=>false,'message'=>'Incorrect Username or Password'));

            }
        }else{
            echo json_encode(array('status'=>false,'message'=>'Please Enter Username and Password.'));

        }
    }

    /**
     * This function is used to get all inquiries
     */
    public function getProfile()
    {

        $headers  = getallheaders();
        if(!empty($headers)){
            $hdrs = array();
            foreach ($headers as $name => $value) {
                $hdrs[$name] = $value;
            }
            if(isset($hdrs['token']) && $hdrs['token']!=''){
               $user = $this->db->select('id, is_admin')->from('admin_user')->where('token',$hdrs['token'])->get()->result_array();
                if(!empty($user)){
                    
                    $result = $this->inquiries_model->getProfile($user[0]);
                    if(count($result)){
                        echo json_encode(array('status'=>true,'data'=>$result));
                    }else{
                        echo json_encode(array('status'=>false,'message'=>'No Inquiries Found.'));
                    }

                }
            }
        }

        

    }

    /**
     * This function is used to get all inquiries
     */
    public function getAllInquiries()
    {

        $result = $this->inquiries_model->getInquiries();
        if(count($result)){
            echo json_encode(array('status'=>true,'data'=>$result));
        }else{
            echo json_encode(array('status'=>false,'message'=>'No Inquiries Found.'));
        }

    }

    private function isLoggedIn(){
        $headers  = getallheaders();
        if(!empty($headers)){
            $hdrs = array();
            foreach ($headers as $name => $value) {
                $hdrs[$name] = $value;
            }
            if(isset($hdrs['token']) && $hdrs['token']!=''){
               $user = $this->db->select('id')->from('admin_user')->where('token',$hdrs['token'])->get()->num_rows();
                if($user>0){
               return true;
                }else{
                    echo json_encode(array('status'=>false,'message'=>'Invalid Credentials.')); exit;
                }
            }else{
                echo json_encode(array('status'=>false,'message'=>'Please Login First.')); exit;
            }
        }else{
            echo json_encode(array('status'=>false,'message'=>'Please Login First.')); exit;
        }

    }

}

?>