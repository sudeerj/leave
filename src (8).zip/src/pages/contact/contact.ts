import { Component,ViewChild,ElementRef  } from '@angular/core';
import { NavController } from 'ionic-angular';




@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {

 @ViewChild('map') mapElement: ElementRef;
  map: any;


  constructor(public navCtrl: NavController) {

  }




}
