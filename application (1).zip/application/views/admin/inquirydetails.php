

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-gears"></i> View Inquiry

        </h1>
    </section>

    <section class="content">

        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
                <!-- general form elements -->



                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">View Inquiry Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->


                       <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="brandname">Name : </label> <span><?php echo $inquirydetails[0]['name'];?></span>

                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="brandname">Email : </label> <span><?php echo $inquirydetails[0]['email'];?></span>
                                    </div>

                                </div>
                            </div>
                           <div class="row">
                               <div class="col-md-6">
                                   <div class="form-group">
                                       <label for="brandname">Message : </label> <span><?php echo $inquirydetails[0]['message'];?></span>
                                   </div>

                               </div>
                           </div>
                           <?php if($inquirydetails[0]['product_id']!=0){ ?>
                               <div class="row">
                                   <div class="col-md-6">
                                       <div class="form-group">
                                           <label for="brandname">Product Name : </label> <span><?php echo $inquirydetails[0]['prodname'];?></span>

                                       </div>

                                   </div>
                               </div>
                               <div class="row">
                                   <div class="col-md-6">
                                       <div class="form-group">
                                           <label for="brandname">Product SKU : </label> <span><?php echo $inquirydetails[0]['product_sku'];?></span>
                                       </div>

                                   </div>
                               </div>
                               <div class="row">
                                   <div class="col-md-6">
                                       <div class="form-group">
                                           <label for="brandname">Manufacturer : </label> <span><?php echo $inquirydetails[0]['manuname'];?></span>
                                       </div>

                                   </div>
                               </div>


<?php } ?>
                           <div class="row">
                               <div class="col-md-6">
                                   <div class="form-group">
                                       <label for="brandname">Business Type : </label> <span><?php echo ($inquirydetails[0]['business_type']==1)?'Retails':'Wholesale';?></span>
                                   </div>

                               </div>
                           </div>
                           <div class="row">
                               <div class="col-md-6">
                                   <div class="form-group">
                                       <label for="brandname">Country : </label> <span><?php echo $inquirydetails[0]['cname']?></span>
                                   </div>

                               </div>
                           </div>
                           <div class="row">
                               <div class="col-md-6">
                                   <div class="form-group">
                                       <label for="brandname">Created At : </label> <span><?php echo date('d M Y',strtotime($inquirydetails[0]['created_at']));?></span>
                                   </div>

                               </div>
                           </div>

                        </div><!-- /.box-body -->



                </div>
            </div>
            <div class="col-md-4">


                <div class="row">
                    <div class="col-md-12">
                         </div>
                </div>
            </div>
        </div>
    </section>

</div>
</div>