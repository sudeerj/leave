<?php


class Blog_model extends CI_Model {

    /**
     * Constructor
     *
     */

    function __Construct()
    {
        parent::__Construct();
    }

//End of getUsers Function

    /**
     * This function is used to get the case listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function blogListingCount($searchText = '')
    {
        $this->db->select('id');
        $this->db->from('blogs as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.title  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if($this->session->userdata('role')=='admin'){
            $this->db->where('brand_id',$this->session->userdata('userId'));
        }
        $this->db->where('status !=',3);
        $query = $this->db->get();

        return count($query->result());
    }

    /**
     * This function is used to get the case listing
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function blogListing($searchText = '', $page, $segment)
    {
        $this->db->select('*');
        $this->db->from('blogs as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.title  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if($this->session->userdata('role')=='admin'){
            $this->db->where('brand_id',$this->session->userdata('userId'));
        }
        $this->db->where('status !=',3);
        $this->db->limit($page, $segment);
        $query = $this->db->get();

        $result = $query->result();
        return $result;
    }
    /**
     * This function is used to delete the case information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteBlog($userId, $userInfo)
    {
        $this->db->where('id', $userId);
        $this->db->update('blogs', $userInfo);

        return $this->db->affected_rows();
    }
    /**
     * This function used to get case information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getBlogInfo($userId)
    {
        $this->db->select('*');
        $this->db->from('blogs');
        $this->db->where('status !=', 3);
        $this->db->where('id', $userId);
        if($this->session->userdata('role')=='admin'){
            $this->db->where('brand_id',$this->session->userdata('userId'));
        }
        $query = $this->db->get();

        return $query->result();
    }

    /**
     * This function is used to update the case information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function editBlog($userInfo, $userId)
    {
        $this->db->where('id', $userId);
        $this->db->update('blogs', $userInfo);

        return TRUE;
    }
}