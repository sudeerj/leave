<?php

class Products_model extends CI_Model {

    /**
     * Constructor
     *
     */

    function __Construct()
    {
        parent::__Construct();
    }

// --------------------------------------------------------------------

    /**
     * Get Products
     *
     * @access	private
     * @param	array	conditions to fetch data
     * @return	object	object with result set
     */
    function getProducts($id='')
    {

        $this->db->select('products.*,manufacturer.name as manuname,manufacturer.contact_number');

        if($id=''){
            $this->db->where('products.id',$id);
        }
        $this->db->from('products');
        $this->db->join('manufacturer','manufacturer.id=products.manufacturer_id');
        $this->db->order_by("products.id", "asc");

        $result = $this->db->get();

        return $result->result_array();


    }
    /**
     * Get Products
     *
     * @access	private
     * @param	array	conditions to fetch data
     * @return	object	object with result set
     */
    function getManufacturer($id='')
    {

        $this->db->select('*');

        if($id=''){
            $this->db->where('manufacturer.id',$id);
        }
        $this->db->from('manufacturer');
        $this->db->order_by("manufacturer.id", "asc");

        $result = $this->db->get();

        return $result->result_array();


    }
}