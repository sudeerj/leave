<?php

class Users_model extends CI_Model {

    /**
     * Constructor
     *
     */

    function __Construct()
    {
        parent::__Construct();
    }


    // --------------------------------------------------------------------

    /**
     * Get Users
     *
     * @access	private
     * @param	array	conditions to fetch data
     * @return	object	object with result set
     */
    function getUsers($conditions=array(),$fields='')
    {

        parent::__construct();


        if (count($conditions) > 0){
            $this->db->where($conditions);
    }

        $this->db->where('brand_id',$this->session->userdata('brand_id'));
        $this->db->where('status',1);
        $this->db->from('ci_users');

        $this->db->order_by("ci_users.user_id", "asc");


        if($fields!='')
            $this->db->select($fields);
        else
            $this->db->select('*');

        $result = $this->db->get();

        return $result;


    }//End of getUsers Function

    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function userListingCount($searchText = '')
    {
        $this->db->select('user_id');
        $this->db->from('ci_users as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.password  LIKE '%".$searchText."%'
                            OR  BaseTbl.full_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if($this->session->userdata('role')=='admin'){
            $this->db->where('brand_id',$this->session->userdata('userId'));
        }
        $this->db->where('status',1);
        $query = $this->db->get();

        return count($query->result());
    }

    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function userListing($searchText = '', $page, $segment)
    {
        $this->db->select('*');
        $this->db->from('ci_users as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.password  LIKE '%".$searchText."%'
                            OR  BaseTbl.full_name  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        if($this->session->userdata('role')=='admin'){
            $this->db->where('brand_id',$this->session->userdata('userId'));
        }
        $this->db->where('status',1);
        $this->db->limit($page, $segment);
        $query = $this->db->get();

        $result = $query->result();
        return $result;
    }
    /**
     * This function is used to delete the user information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteUser($userId, $userInfo)
    {
        $this->db->where('user_id', $userId);
        $this->db->update('ci_users', $userInfo);

        return $this->db->affected_rows();
    }
    /**
     * This function used to get user information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getUserInfo($userId)
    {
        $this->db->select('*');
        $this->db->from('ci_users');
        $this->db->where('status', 1);
        $this->db->where('user_id', $userId);
        $query = $this->db->get();

        return $query->result();
    }

    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function editUser($userInfo, $userId)
    {
        $this->db->where('user_id', $userId);
        $this->db->update('ci_users', $userInfo);

        return TRUE;
    }

    /**
     * This function is used to match users password for change password
     * @param number $userId : This is user id
     */
    function matchOldPassword($userId, $oldPassword)
    {
        if($this->session->userdata('role')=='admin') {
            $this->db->select('id, password');
            $this->db->where('id', $userId);
            $this->db->where('status', 1);
            $query = $this->db->get('brand');
        }elseif ($this->session->userdata('role')=='superadmin'){
            $this->db->select('id, password');
            $this->db->where('id', $userId);
            $query = $this->db->get('admin_user');
        }
        $user = $query->result();

        if(!empty($user)){
            if(md5($oldPassword) == $user[0]->password){
                return $user;
            } else {
                return array();
            }
        } else {
            return array();
        }
    }

    /**
     * This function is used to change users password
     * @param number $userId : This is user id
     * @param array $userInfo : This is user updation info
     */
    function changePassword($userId, $userInfo)
    {

        if($this->session->userdata('role')=='admin') {

            $this->db->where('id', $userId);
            $this->db->update('brand', $userInfo);

        }elseif ($this->session->userdata('role')=='superadmin'){
            $this->db->where('id', $userId);
            $this->db->update('admin_user', $userInfo);

        }


        return $this->db->affected_rows();
    }
}