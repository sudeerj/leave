<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/




/*********** USER DEFINED ROUTES *******************/
$route['admin'] = 'admin/login';
$route['admin/loginMe'] = 'admin/login/loginMe';
$route['admin/dashboard'] = 'admin/user';
$route['admin/logout'] = 'admin/login/logout';
$route['admin/userListing'] = 'admin/user/userListing';
$route['admin/userListing/(:num)'] = "admin/user/userListing/$1";
$route['admin/authorListing'] = 'admin/authors/authorListing';
$route['admin/authorListing/(:num)'] = "admin/authors/authorListing/$1";
$route['admin/settings'] = "admin/user/settings";
$route['admin/accessdenied'] = "admin/user/accessdenied";
//$route['admin/cases'] = 'admin/user';
$route['admin/addNewCase'] = 'admin/cases/addNewCase';
$route['admin/cases/(:num)'] = "admin/cases/index/$1";
$route['admin/editCase'] = "admin/cases/editCase";
$route['admin/editCase/(:num)'] = "admin/cases/editCase/$1";
$route['admin/deleteCase'] = "admin/cases/deleteCase";
$route['admin/addNewBlog'] = 'admin/blogs/addNewBlog';
$route['admin/blogs/(:num)'] = "admin/blogs/index/$1";
$route['admin/editBlog'] = "admin/blogs/editBlog";
$route['admin/editBlog/(:num)'] = "admin/blogs/editBlog/$1";
$route['admin/deleteBlog'] = "admin/blogs/deleteBlog";
$route['admin/addNewEvent'] = 'admin/events/addNewEvent';
$route['admin/events/(:num)'] = "events/index/$1";
$route['admin/editEvent'] = "admin/events/editEvent";
$route['admin/editEvent/(:num)'] = "admin/events/editEvent/$1";
$route['admin/deleteEvent'] = "admin/events/deleteEvent";
$route['admin/addNewBrand'] = 'admin/brands/addNewBrand';
$route['admin/brandListing'] = 'admin/brands/brandListing';
$route['admin/brandListing/(:num)'] = "admin/brands/brandListing/$1";
$route['admin/editBrand'] = "admin/brands/editBrand";
$route['admin/editBrand/(:num)'] = "admin/brands/editBrand/$1";
$route['admin/deleteBrand'] = "admin/brands/deleteBrand";
$route['admin/addNewUser'] = "admin/user/addNewUser";
$route['admin/editOld'] = "admin/user/editOld";
$route['admin/editOld/(:num)'] = "admin/user/editOld/$1";
$route['admin/editUser'] = "admin/user/editUser";
$route['admin/deleteUser'] = "admin/user/deleteUser";

$route['admin/loadChangePass'] = "admin/user/loadChangePass";
$route['admin/changePassword'] = "admin/user/changePassword";
$route['pageNotFound'] = "user/pageNotFound";
$route['checkEmailExists'] = "user/checkEmailExists";

$route['forgotPassword'] = "login/forgotPassword";
$route['resetPasswordUser'] = "login/resetPasswordUser";
$route['resetPasswordConfirmUser'] = "login/resetPasswordConfirmUser";
$route['resetPasswordConfirmUser/(:any)'] = "login/resetPasswordConfirmUser/$1";
$route['resetPasswordConfirmUser/(:any)/(:any)'] = "login/resetPasswordConfirmUser/$1/$2";
$route['createPasswordUser'] = "login/createPasswordUser";
$route['alias'] = "login/alias";
$route['casedetails/(:num)'] = "site/casedetails/$1";
$route['events'] = "site/events";
$route['blogs'] = "site/blogs";
$route['logout'] = "login/logout";
$route['addblog'] = "site/addblog";
$route['blogdetails/(:num)'] = "site/blogdetails/$1";
$route['default_controller'] = "site";
$route['404_override'] = 'error';
/* End of file routes.php */
/* Location: ./application/config/routes.php */