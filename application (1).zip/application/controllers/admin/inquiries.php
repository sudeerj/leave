<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';


class Inquiries extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('inquiries_model');
        //$this->load->model('Constant_model');
        $this->isLoggedIn();

    }


    /**
     * This function is used to load the user list
     */
    function index()
    {



            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;

            $this->load->library('pagination');

            //$count = $this->enquiries_model->userListingCount($searchText);

           // $returns = $this->paginationCompress("admin/enquiries/index/", $count, 5);
        //$result =
            $data['inquiries'] = $this->inquiries_model->getInquiries();

            $this->global['pageTitle'] = 'Inquiry System : Enquiries Listing';

            $this->loadViews("enquiries", $this->global, $data, NULL);

    }
    /**
     * This function is used to load the user list
     */
    function view($id)
    {

        $data['inquirydetails'] = $this->inquiries_model->getInquiriedetails($id);

        $this->global['pageTitle'] = 'Inquiry System : Enquiries Listing';

        $this->loadViews("inquirydetails", $this->global, $data, NULL);

    }



    function pageNotFound()
    {
        $this->global['pageTitle'] = 'WeShareMed : 404 - Page Not Found';

        $this->loadViews("404", $this->global, NULL, NULL);
    }
}