<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : sudeera
 * @version : 1.1
 * @since : 31/7/2017
 */
class User extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();
        $this->load->model('inquiries_model');

    }

    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {

        $this->global['pageTitle'] = 'Inquiry System : Dashboard';

        $data['userscount'] = $this->inquiries_model->getInquiries();
        //$data['casescount'] = $this->case_model->caseListingCount();
        //$data['blogscount'] = $this->blog_model->blogListingCount();
        //$data['eventscount'] = $this->event_model->eventListingCount();

        $this->loadViews("dashboard", $this->global, $data, NULL);

    }

    /**
     * This function is used to load the user list
     */
    function userListing()
    {


        $this->load->model('user_model');

        $searchText = $this->input->post('searchText');
        $data['searchText'] = $searchText;

        $this->load->library('pagination');

        $count = $this->users_model->userListingCount($searchText);

        $returns = $this->paginationCompress("admin/userListing/", $count, 10);

        $data['userRecords'] = $this->users_model->userListing($searchText, $returns["page"], $returns["segment"]);

        $this->global['pageTitle'] = 'WeShareMed : User Listing';

        $this->loadViews("users", $this->global, $data, NULL);


    }

    public	function ExcelDataAdd()	{
        if($_FILES) {
            $this->load->library('excel');
//Path of files were you want to upload on localhost (C:/xampp/htdocs/ProjectName/uploads/excel/)
            $config['upload_path'] = './uploads/excels/';
            $config['allowed_types'] = 'xls|xlsx';
            $config['max_size'] = '5000';
            $this->load->library('upload', $config);
            // uploded file extension
            if (!$this->upload->do_upload('userfile', FALSE)) {
                $this->session->set_flashdata('error', $this->upload->display_errors());

                redirect('admin/user/ExcelDataAdd');

            } else {
                $upload_data =  $this->upload->data();
                $file_name = $upload_data['file_name'];
                $zfile = $upload_data['full_path']; // get file path
                chmod($zfile, 0777);
                $brand = $this->brands_model->getBrandInfo($this->session->userdata('userId'));
                $brandname = $brand[0]->name;
                $this->load->library('excel');
                //read file from path
                $objPHPExcel = PHPExcel_IOFactory::load($zfile);

//get only the Cell Collection
                $cell_collection = $objPHPExcel->getActiveSheet()->getCellCollection();

//extract to a PHP readable array format
                foreach ($cell_collection as $cell) {
                    $column = $objPHPExcel->getActiveSheet()->getCell($cell)->getColumn();
                    $row = $objPHPExcel->getActiveSheet()->getCell($cell)->getRow();
                    $data_value = $objPHPExcel->getActiveSheet()->getCell($cell)->getValue();

                    //header will/should be in row 1 only. of course this can be modified to suit your need.
                    if ($row == 1) {
                        $header[$column] = $data_value;
                    } else {
                        $arr_data[$row][$column] = $data_value;
                    }
                }

//send the data in an array format
                $data['header'] = $header;
                $data['values'] = $arr_data;
                //echo "<pre>";print_r($data);exit;
                if (!empty($data['header']) && !empty($data['values'])) {
                    foreach ($data['header'] as $k => $v) {
                        foreach ($data['values'] as $key => $value) {
                            if (isset($value[$k])) {
                                $adata[$key][$k] = $value[$k];
                            } else {
                                $adata[$key][$k] = '';
                            }

                        }
                    }
                    $insertdata = array();

                    $sendmaildata = array();
                    $lastuser = $this->db->select('password')->where('brand_id', $this->session->userdata('userId'))->where('status',1)->from('ci_users')->order_by('user_id ', 'DESC')->limit(1)->get()->row_array();
                    if (!empty($lastuser)) {
                        $c = substr($lastuser['password'], -1);
                       $c += 1;
                        /*$password = $brandname . $c;
                        $string = preg_replace('/\s+/', '', $brandname);
                        $pass = $string . $c;*/
                    } else {
                        $c = 1;
                        /*$password = $brandname . "1";
                        $string = preg_replace('/\s+/', '', $brandname);
                        $pass = $string . "1";*/
                    }

                    if (!empty($adata)) {
                        $password = '';
                        $string = '';
                        $pass = '';
                        foreach ($adata as $key => $item) {


                            $insertdata[$key]['full_name'] = $item['A'];
                            $insertdata[$key]['degree'] = $item['B'];
                            $insertdata[$key]['location'] = trim($item['C']);
                            $insertdata[$key]['created_at'] = date('Y-m-d h:i:s');
                            $insertdata[$key]['brand_id'] = $this->session->userdata('userId');
                            $password = $brandname.$c;
                            $string = preg_replace('/\s+/', '', $brandname);
                            $pass = $string . $c;
                            $insertdata[$key]['password'] = $password;
                            $insertdata[$key]['pass'] = $pass;
                            $c++;
                        }
                    }
                    if(!empty($insertdata)) {
                        //$insert = 1;
                        $insert = $this->db->insert_batch('ci_users', $insertdata);
                    }else{
                        $this->session->set_flashdata('error','Failed to import data from excel !! Thers is error in excel file');
                        redirect('admin/user/ExcelDataAdd');
                    }
                    //echo "<pre>";print_r($insertdata);exit;
                }

                unlink('./uploads/excels/' . $file_name); //File Deleted After uploading in database .
                $this->session->set_flashdata('success','You have successfully imported users data.');
                redirect('admin/userListing');
            }
//$objReader =PHPExcel_IOFactory::createReader('Excel5');     //For excel 2003

        }else{
            $this->global['pageTitle'] = 'WeShareMed : Excel Upload';

            $this->loadViews("excelupload", $this->global, null, NULL);
        }

    }



    /**
     * This function is used to upload pictures in florala editor
     */
    function upload_image()
    {

        try {
            // File Route.
            $fileRoute = "/../../../uploads/";

            $fieldname = "file";

            // Get filename.
            $filename = explode(".", $_FILES[$fieldname]["name"]);

            // Validate uploaded files.
            // Do not use $_FILES["file"]["type"] as it can be easily forged.
          //  $finfo = finfo_open(FILEINFO_MIME_TYPE);

            // Get temp file name.
            $tmpName = $_FILES[$fieldname]["tmp_name"];

            // Get mime type.
           // $mimeType = finfo_file($finfo, $tmpName);

            // Get extension. You must include fileinfo PHP extension.
            $extension = end($filename);

            // Allowed extensions.
            $allowedExts = array("gif", "jpeg", "jpg", "png", "svg", "blob");

            // Allowed mime types.
            //$allowedMimeTypes = array("image/gif", "image/jpeg", "image/pjpeg", "image/x-png", "image/png", "image/svg+xml");

            // Validate image.
           /* if (!in_array(strtolower($mimeType), $allowedMimeTypes) || !in_array(strtolower($extension), $allowedExts)) {
                throw new \Exception("File does not meet the validation.");
            }*/

            // Generate new random name.
            $name = sha1(microtime()) . "." . $extension;
            $fullNamePath = dirname(__FILE__) . $fileRoute.$name;

            // Check server protocol and load resources accordingly.
            if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] != "off") {
                $protocol = "https://";
            } else {
                $protocol = "http://";
            }

            // Save file in the uploads folder.
            move_uploaded_file($tmpName, $fullNamePath);

            // Generate response.
            $response = new \StdClass;
            $response->link = base_url(). "uploads/" . $name;

            // Send response.
            echo stripslashes(json_encode($response));

        } catch (Exception $e) {
            // Send error response.
            echo $e->getMessage();
            http_response_code(404);
        }

    }
    /**
     * This function is used to upload file in florala editor
     */
    function upload_file()
    {

        try {
            // File Route.
            $fileRoute = "/../../../uploads/files/";

            $fieldname = "file";

            // Get filename.
            $filename = explode(".", $_FILES[$fieldname]["name"]);

            // Validate uploaded files.
            // Do not use $_FILES["file"]["type"] as it can be easily forged.
            //$finfo = finfo_open(FILEINFO_MIME_TYPE);

            // Get temp file name.
            $tmpName = $_FILES[$fieldname]["tmp_name"];

            // Get mime type.
           // $mimeType = finfo_file($finfo, $tmpName);
///echo $mimeType;
            // Get extension. You must include fileinfo PHP extension.
            $extension = end($filename);

            // Allowed extensions.
            $allowedExts = array("doc", "docx", "ppt", "pot", "pps", "ppa","pptx","pdf");

            // Allowed mime types.
            $allowedMimeTypes = array("application/pdf","application/vnd.openxmlformats-officedocument.presentationml.presentation","application/vnd.openxmlformats-officedocument.presentationml.slideshow", "application/vnd.ms-powerpoint", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");

            // Validate image.
            /*if (!in_array(strtolower($mimeType), $allowedMimeTypes) || !in_array(strtolower($extension), $allowedExts)) {
                throw new \Exception("File does not meet the validation.");
            }*/

            // Generate new random name.
            $name = sha1(microtime()) . "." . $extension;
            $fullNamePath = dirname(__FILE__) . $fileRoute.$name;

            // Check server protocol and load resources accordingly.
            if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] != "off") {
                $protocol = "https://";
            } else {
                $protocol = "http://";
            }

            // Save file in the uploads folder.
            move_uploaded_file($tmpName, $fullNamePath);

            // Generate response.
            $response = new \StdClass;
            $response->link = base_url(). "uploads/files/" . $name;

            // Send response.
            echo stripslashes(json_encode($response));

        } catch (Exception $e) {
            // Send error response.
            echo $e->getMessage();
            http_response_code(404);
        }

    }
    /**
     * This function is used to load the add new form
     */
    function settings()
    {
        if ($this->isAdmin()) {
            $this->loadThis();
        } else {

            if ($_FILES) {

                $this->load->library('form_validation');
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'jpg|jpeg|png';
                $config['max_size'] = '1000';
                $config['max_width'] = '170';
                $config['max_height'] = '75';
                $new_name = time() . $_FILES["logo"]['name'];
                $config['file_name'] = $new_name;
                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('logo', FALSE)) {
                    $this->session->set_flashdata('error', $this->upload->display_errors());

                    redirect('admin/settings');

                } else {
                    $updatedata['logo'] = $new_name;
                    $update = $this->brands_model->editBrand($updatedata, $this->session->userdata('userId'));
                    if ($update) {
                        $this->session->set_flashdata('success', 'You have updated Brand Logo successfully.');
                        redirect('admin/settings');
                    }
                }

            } else {
                $data['branddetails'] = $this->brands_model->getBrandInfo($this->session->userdata('userId'));
                $this->global['pageTitle'] = 'WeShareMed : Brand Name';

                $this->loadViews("settings", $this->global, $data, NULL);

            }
        }
    }

    /**
     * This function is used to check whether email already exist or not
     */
    function checkEmailExists()
    {
        $userId = $this->input->post("userId");
        $email = $this->input->post("email");

        if (empty($userId)) {
            $result = $this->user_model->checkEmailExists($email);
        } else {
            $result = $this->user_model->checkEmailExists($email, $userId);
        }

        if (empty($result)) {
            echo("true");
        } else {
            echo("false");
        }
    }

    /**
     * This function is used to add new user to the system
     */
    function addNewUser()
    {
        if ($this->isAdmin()) {
            $this->loadThis();
        } else {
            if ($_POST) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('fullname', 'Full Name', 'trim|required|max_length[255]|xss_clean');
                if ($this->form_validation->run() == FALSE) {
                    $this->addNewUser();
                } else {
                    $brand = $this->brands_model->getBrandInfo($this->session->userdata('userId'));
                    $brandname = $brand[0]->name;
                    if ($brandname != '') {
                        $lastuser = $this->db->select('password')->where('brand_id', $this->session->userdata('userId'))->where('status',1)->from('ci_users')->order_by('user_id ', 'DESC')->limit(1)->get()->row_array();
                        if (!empty($lastuser)) {
                            $c = substr($lastuser['password'], -1);
                            $c += 1;
                            $data['password'] = $brandname . $c;
                            $string = preg_replace('/\s+/', '', $brandname);
                            $data['pass'] = $string . $c;
                        } else {
                            $data['password'] = $brandname . "1";
                            $string = preg_replace('/\s+/', '', $brandname);
                            $data['pass'] = $string . "1";
                        }

                        $data['full_name'] = $this->input->post('fullname');
                        $data['degree'] = $this->input->post('degree');
                        $data['location'] = $this->input->post('location');
                        $data['brand_id'] = $this->session->userdata('userId');
                        $data['created_at'] = date('Y-m-d h:i:s');
                        $insert = $this->Constant_model->insertData('ci_users', $data);
                        if ($insert) {
                            $this->session->set_flashdata('success', 'You have added User successfully.');
                            redirect('admin/userListing');
                        }
                    } else {
                        $this->session->set_flashdata('error', 'Please First Create Your Brand name.');
                        redirect('admin/addNewUser');
                    }
                }

            } else {
                // $data['brandname'] = $this->Constant_model->getDataWhere('brand');
                $this->global['pageTitle'] = 'WeShareMed : Add User';

                $this->loadViews("adduser", $this->global, NULL);

            }
        }

    }


    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOld($userId = NULL)
    {

        if ($userId == null) {
            redirect('userListing');
        }
        if ($_POST) {
            $fullname = $this->input->post('fullname');
            $degree = $this->input->post('degree');
            $location = $this->input->post('location');
            if ($fullname != '') {
                $userInfo = array('full_name' => $fullname,'degree'=>$degree,'location'=>$location, 'updated_by' => 'admin', 'updated_at' => date('Y-m-d H:i:s'));
            } else {
                $userInfo = array('updated_by' => 'admin', 'updated_at' => date('Y-m-d H:i:s'));

            }
            $result = $this->users_model->editUser($userInfo, $userId);
            if ($result == true) {
                $this->session->set_flashdata('success', 'User updated successfully');
            } else {
                $this->session->set_flashdata('error', 'User updation failed');
            }

            redirect('admin/userListing');
        } else {
            $data['userInfo'] = $this->users_model->getUserInfo($userId);

            $this->global['pageTitle'] = 'WeShareMed : Edit User';

            $this->loadViews("editOld", $this->global, $data, NULL);
        }

    }


    /**
     * This function is used to edit the user information
     */
    function editUser()
    {
        if ($this->isAdmin() == TRUE) {
            $this->loadThis();
        } else {
            $this->load->library('form_validation');

            $userId = $this->input->post('userId');

            $this->form_validation->set_rules('fname', 'Full Name', 'trim|required|max_length[128]|xss_clean');
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|xss_clean|max_length[128]');
            $this->form_validation->set_rules('password', 'Password', 'matches[cpassword]|max_length[20]');
            $this->form_validation->set_rules('cpassword', 'Confirm Password', 'matches[password]|max_length[20]');
            $this->form_validation->set_rules('role', 'Role', 'trim|required|numeric');
            $this->form_validation->set_rules('mobile', 'Mobile Number', 'required|min_length[10]|xss_clean');

            if ($this->form_validation->run() == FALSE) {
                $this->editOld($userId);
            } else {
                $name = ucwords(strtolower($this->input->post('fname')));
                $email = $this->input->post('email');
                $password = $this->input->post('password');
                $roleId = $this->input->post('role');
                $mobile = $this->input->post('mobile');

                $userInfo = array();

                if (empty($password)) {
                    $userInfo = array('email' => $email, 'roleId' => $roleId, 'name' => $name,
                        'mobile' => $mobile, 'updatedBy' => $this->vendorId, 'updatedDtm' => date('Y-m-d H:i:sa'));
                } else {
                    $userInfo = array('email' => $email, 'password' => getHashedPassword($password), 'roleId' => $roleId,
                        'name' => ucwords($name), 'mobile' => $mobile, 'updatedBy' => $this->vendorId,
                        'updatedDtm' => date('Y-m-d H:i:sa'));
                }

                $result = $this->user_model->editUser($userInfo, $userId);

                if ($result == true) {
                    $this->session->set_flashdata('success', 'User updated successfully');
                } else {
                    $this->session->set_flashdata('error', 'User updation failed');
                }

                redirect('userListing');
            }
        }
    }


    /**
     * This function is used to delete the user using userId
     * @return boolean $result : TRUE / FALSE
     */
    function deleteUser()
    {

        $userId = $this->input->post('userId');
        $userInfo = array('status' => 2, 'updated_at' => date('Y-m-d H:i:s'));

        $result = $this->users_model->deleteUser($userId, $userInfo);

        if ($result > 0) {
            echo(json_encode(array('status' => TRUE)));
        } else {
            echo(json_encode(array('status' => FALSE)));
        }

    }

    /**
     * This function is used to load the change password screen
     */
    function loadChangePass()
    {
        $this->global['pageTitle'] = 'WeShareMed : Change Password';

        $this->loadViews("changePassword", $this->global, NULL, NULL);
    }


    /**
     * This function is used to change the password of the user
     */
    function changePassword()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('oldPassword', 'Old password', 'required|max_length[20]');
        $this->form_validation->set_rules('newPassword', 'New password', 'required|max_length[20]');
        $this->form_validation->set_rules('cNewPassword', 'Confirm new password', 'required|matches[newPassword]|max_length[20]');

        if ($this->form_validation->run() == FALSE) {
            $this->loadChangePass();
        } else {
            $oldPassword = $this->input->post('oldPassword');
            $newPassword = $this->input->post('newPassword');

            $resultPas = $this->users_model->matchOldPassword($this->session->userdata('userId'), $oldPassword);

            if (empty($resultPas)) {
                $this->session->set_flashdata('nomatch', 'Your old password not correct');
                redirect('admin/loadChangePass');
            } else {
                $usersData = array('password' => md5($newPassword),
                    'updated_at' => date('Y-m-d H:i:s'));

                $result = $this->users_model->changePassword($this->session->userdata('userId'), $usersData);

                if ($result > 0) {
                    $this->session->set_flashdata('success', 'Password updation successful');
                } else {
                    $this->session->set_flashdata('error', 'Password updation failed');
                }

                redirect('admin/loadChangePass');
            }
        }
    }

    function pageNotFound()
    {
        $this->global['pageTitle'] = 'WeShare : 404 - Page Not Found';

        $this->loadViews("404", $this->global, NULL, NULL);
    }
}

?>