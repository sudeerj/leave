import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-mail-body',
  templateUrl: 'mail-body.html',
})
export class MailBodyPage {
  private body:any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
      this.body=this.navParams.get("body");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MailBodyPage');
  }
  sendMail(){

  }
}
