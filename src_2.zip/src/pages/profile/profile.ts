import { Component } from '@angular/core';
import {ActionSheetController, IonicPage, NavController, NavParams} from 'ionic-angular';
import {ImagePicker, ImagePickerOptions} from "@ionic-native/image-picker";
import {ServiceSingleton} from "../../providers/service-singleton";
import {Camera,CameraOptions} from "@ionic-native/camera";

/**
 * Generated class for the ProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage {
  private myimage:any='';
  private cameraOptions: CameraOptions = {
    quality: 100,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE
  }
  private imageOption:ImagePickerOptions={
    quality:100,
    maximumImagesCount:1
  }

  constructor(public navCtrl: NavController,
              private webService:ServiceSingleton,
              public actionSheetCtrl: ActionSheetController,
              private imagePicker:ImagePicker,
              private camera:Camera,
              public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProfilePage');
  }
  uploadProfilePic(){
    console.log("upload pic");
    let actionSheet=this.actionSheetCtrl.create({
      title: 'Profile Photo',
      buttons: [
        {
          text: 'Upload Image',
          role: 'destructive',
          handler: () => {

            this.imagePicker.getPictures(this.imageOption).then(imagedata=>{
              this.myimage=imagedata;
            })

          }
        },{
          text: 'Open Camera',
          handler: () => {
            this.camera.getPicture(this.cameraOptions).then(imagedata=>{
              console.log(imagedata);
              this.myimage=imagedata;
            })
          }
        },{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    actionSheet.present();

  }


}
