import { Component } from '@angular/core';
import {Events, IonicPage, NavController, NavParams} from 'ionic-angular';
import {ServiceSingleton} from "../../providers/service-singleton";
import { MailComposerPage } from '../mail-composer/mail-composer';
import {MailBodyPage} from "../mail-body/mail-body";
import {RootData} from "@angular/core/src/view";

/**
 * Generated class for the SalesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-sales',
  templateUrl: 'sales.html',
})
export class SalesPage {
  private data:any=[];
  private keys = [];
  private mailKeys=[];
  private SaleYear=[];
  private Banks=[];
  private saleno:any;
  private markedRows=[];
  private discount:boolean=false;
  private cumlative:number=0;
  private bankname:any;
  private pay=0;
  private bal=0;
  private rem_lot=0;
  private rem_pr=0;
  private sel_lot=0;
  private body;
  private post={
    saleyear:"2018",
    saleno:"",
    username:""
  }
  constructor(public navCtrl: NavController,public events:Events,private webService:ServiceSingleton, public navParams: NavParams) {
      this.post.username=this.webService.getUser();
      //this.saleno=this.navParams.get('saleno');
      this.saleno=this.webService.saleno;
      this.getSaleYears();

    this.events.subscribe('opensale',()=>{
        this.saleno=this.webService.saleno;
        this.getSaleYears();
      })
  }
  getData(){
    this.post.saleno=this.saleno.split(" -")[0];
    console.log(this.post);
    this.webService.presentLoading();
    this.webService.postTeaSales(this.post).then((data:any)=>{
      this.webService.stopLoading();
      if(data && data.status==true){
       this.data=data.data;
        this.navCtrl.push(MailComposerPage,{data:data.data,post:this.post});
      }
    })

  }

  getSaleYears(){
    this.webService.presentLoading();
    this.webService.getSaleYear().then((data:any)=>{
      this.webService.stopLoading();
      //this.getBankList();
      if(data && data.status==true){
         this.SaleYear=data.data;
      }
    });
  }



}
