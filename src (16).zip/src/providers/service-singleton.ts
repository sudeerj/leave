import { Injectable, transition } from '@angular/core';
import { Http,Headers } from '@angular/http';
import {Storage} from "@ionic/storage";
import {Events, ToastController, AlertController, LoadingController} from"ionic-angular";
import 'rxjs/add/operator/map';
import { useAnimation } from '@angular/core/src/animation/dsl';
import {FileTransfer, FileTransferObject} from "@ionic-native/file-transfer";

/*
  Generated class for the ServiceSingleton provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ServiceSingleton {

  // private BASE_URL="http://api.livevos.com/api/admin/";
  private BASE_URL="http://019bef9.netsolhost.com/htdocs/fwapp/index.php/api/admin/";
  //private MAIN_URL="http://api2.livevos.com.livevos.com/api/admin/";
  private MAIN_URL="http://019bef9.netsolhost.com/htdocs/fwapp/index.php/api/admin/";
  private data:any;
  private token="";
  private user="";
  private loading:any;
  public profile:any={
    Name:'',
    Email:""
  };
  public saleno;
  constructor(public http: Http,
              public storage:Storage,
              private transfer: FileTransfer,
              private toastCtrl:ToastController,
              private alertCtrl:AlertController,
              private loadingCtrl:LoadingController) {


  }

  checkLogin(){
    return new Promise(resolve=>{
      this.storage.get("TOKEN").then((token)=>{
       console.log(token);
        if(token){
          this.token=token;
          this.storage.get("USER").then((user)=>{
            console.log(user);
            if(user){
              this.user=user;
              resolve(true);
            }else{
              resolve(false);
            }
          });
        }else{
          resolve(false);
        }
      });
    });
  }

  // GET DATA WEBSERVICE

  getData(url) {
    //console.log(this.BASE_URL+service+"/"+this.USER_ID+"/"+this.TOKEN+"/"+this.DEVICE_ID);

    return new Promise(resolve => {
      this.http.get(url)
        .map(res => res.json())
        .subscribe(data => {
            this.data = data;
            resolve(this.data);
          },
          err=>{
            console.log("error Occured");
            this.presentToast("Something Went wrong!");
            resolve(false);
          }
        );
    });

  }

  //POSTMETHOD WITHOUT TOKEN

  postData(url,data){
    var form = new FormData();
    for ( var key in data ) {
      console.log(key);
      form.append(key, data[key]);

    }
    console.log(form);
    return new Promise(resolve => {
      this.http.post(url,
        form
        /*, {
          headers:new Headers({'Content-Type': 'application/json'})
        }*/
        )
        .map(res => res.json())
        .subscribe(data => {
          this.data = data;
          resolve(this.data);
        },err=>{
          console.log("error Occured");
          this.presentToast("Something Went wrong!");
          resolve(false);
        });
    });
  }
  //GET DATA WITH TOKEN
  getDataToken(url){
    let headers = new Headers();
    //headers.append('content-type','application/json');
    headers.append('token',this.token);

    return new Promise(resolve => {
      this.http.get(url
        , {
         headers:headers
         }
        )
        .map(res => res.json())
        .subscribe(data => {
          this.data = data;
          resolve(this.data);
        },err=>{
          console.log("error Occured"+err);
          this.presentToast("Something Went wrong!");
          resolve(false);
        });
    });
  }
  // POST METHOD WITH TOKEN

  postDataToken(url,data){
    let headers = new Headers();
    //headers.append('content-type','application/json');
    headers.append('token',this.token);

    return new Promise(resolve => {
      this.http.post(url,
        data
        , {
         headers:headers
         }
        )
        .map(res => res.json())
        .subscribe(data => {
          this.data = data;
          resolve(this.data);
        },err=>{
          console.log("error Occured"+err);
          this.presentToast("Something Went wrong!");
          resolve(false);
        });
    });
  }

  //GENERAL FUNCTIONS

  presentToast(msg) {
    let toast = this.toastCtrl.create({
      message: msg,
      position: 'top',
      showCloseButton: true,
      closeButtonText: 'OK',
      dismissOnPageChange: false
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }
  presentLoading(){
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }
  stopLoading(){
    this.loading.dismiss();
  }

  presentAlert(subTitle) {
    let alert = this.alertCtrl.create({
      title: 'Attention!',
      subTitle: subTitle,
      buttons: [{
        text:'OK',
      }],
      cssClass:'alertcss'
    });
    alert.present();
  }
  //GETTER SETTER

  setToken(token){
    this.token=token;
    this.storage.set("TOKEN",this.token);
  }
  setUser(user){
    this.user=user;
    this.storage.set("USER",this.user);
  }
  getUser(){
    return this.user;
  }
  //APIS WEB SERVICES

  postLogin(data){
    console.log(JSON.stringify(data));
    var url=this.BASE_URL+"login";
    console.log(url);
    return this.postData(url,data);
  }

  postUserDetails(){

    return this.postDataToken(this.BASE_URL+'getProfile','');
  }

  postTeaSales(data){
    var form = new FormData();
    for ( var key in data ) {
      form.append(key, data[key]);
    }
    console.log(this.MAIN_URL+'getTeaSales');
    return this.postDataToken(this.MAIN_URL+'getTeaSales',form);
  }
  getSaleYear(){
    var u=this.MAIN_URL+"getSaleYSaleN";
    return this.getDataToken(u);
  }
  getBankList(){
    var u=this.MAIN_URL+"bank_list";
    return this.getDataToken(u);
  }
  postImage(targetPath,filename){
    var u=this.MAIN_URL+"bank_list";
    var options = {
      fileKey: "file",
      fileName: filename,
      chunkedMode: false,
      mimeType: "multipart/form-data",
      params : {'fileName': filename}
    };
    const fileTransfer: FileTransferObject = this.transfer.create();


    this.presentLoading();
    // Use the FileTransfer to upload the image
    fileTransfer.upload(targetPath, u, options).then(data => {
      this.presentToast("Image succesful uploaded.")

    }, err => {
      this.stopLoading();
      this.presentToast('Error while uploading file.');
    });
  }
  postEmail(data){
    var u=this.MAIN_URL+"user_send_email";
    return this.postDataToken(u,data);
  }

}
